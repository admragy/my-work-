"""
Ad Learning Service - يراقب إعلانات العميل ويتعلم منها
يحلل الإعلانات الناجحة ويستخرج الأنماط الفعالة
"""

import os
import json
import asyncio
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import httpx

try:
    from openai import OpenAI
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False


class AdLearningService:
    """خدمة التعلم من إعلانات العميل"""
    
    def __init__(self):
        self.learned_patterns = {}
        self.successful_ads = []
        self.ad_insights = {}
        
        if HAS_OPENAI and os.environ.get("OPENAI_API_KEY"):
            self.openai_client = OpenAI()
        else:
            self.openai_client = None
    
    async def fetch_user_ads(self, access_token: str, ad_account_id: str) -> List[Dict]:
        """جلب إعلانات المستخدم من فيسبوك"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"https://graph.facebook.com/v18.0/{ad_account_id}/ads",
                    params={
                        "access_token": access_token,
                        "fields": "id,name,status,creative,insights{impressions,clicks,spend,actions,cost_per_action_type,ctr,cpc}",
                        "limit": 50
                    },
                    timeout=30
                )
                
                if response.status_code == 200:
                    data = response.json()
                    return data.get("data", [])
                else:
                    print(f"Error fetching ads: {response.text}")
                    return []
        except Exception as e:
            print(f"Error in fetch_user_ads: {e}")
            return []
    
    async def analyze_ad_performance(self, ads: List[Dict]) -> Dict:
        """تحليل أداء الإعلانات"""
        analysis = {
            "total_ads": len(ads),
            "successful_ads": [],
            "average_ctr": 0,
            "average_cpc": 0,
            "best_performing": None,
            "patterns": []
        }
        
        ctrs = []
        cpcs = []
        
        for ad in ads:
            insights = ad.get("insights", {}).get("data", [{}])[0] if ad.get("insights") else {}
            
            ctr = float(insights.get("ctr", 0))
            cpc = float(insights.get("cpc", 0))
            
            ctrs.append(ctr)
            if cpc > 0:
                cpcs.append(cpc)
            
            if ctr > 2.0:
                analysis["successful_ads"].append({
                    "id": ad.get("id"),
                    "name": ad.get("name"),
                    "ctr": ctr,
                    "cpc": cpc,
                    "creative": ad.get("creative")
                })
        
        if ctrs:
            analysis["average_ctr"] = sum(ctrs) / len(ctrs)
        if cpcs:
            analysis["average_cpc"] = sum(cpcs) / len(cpcs)
        
        if analysis["successful_ads"]:
            analysis["best_performing"] = max(analysis["successful_ads"], key=lambda x: x["ctr"])
        
        return analysis
    
    async def extract_winning_patterns(self, successful_ads: List[Dict], access_token: str) -> List[Dict]:
        """استخراج الأنماط الفائزة من الإعلانات الناجحة"""
        patterns = []
        
        for ad in successful_ads[:10]:
            creative_id = ad.get("creative", {}).get("id")
            if creative_id:
                try:
                    async with httpx.AsyncClient() as client:
                        response = await client.get(
                            f"https://graph.facebook.com/v18.0/{creative_id}",
                            params={
                                "access_token": access_token,
                                "fields": "title,body,call_to_action_type,image_url,video_id,link_url"
                            },
                            timeout=15
                        )
                        
                        if response.status_code == 200:
                            creative_data = response.json()
                            patterns.append({
                                "ad_id": ad["id"],
                                "ad_name": ad["name"],
                                "ctr": ad["ctr"],
                                "headline": creative_data.get("title", ""),
                                "body": creative_data.get("body", ""),
                                "cta": creative_data.get("call_to_action_type", ""),
                                "has_video": bool(creative_data.get("video_id")),
                                "has_image": bool(creative_data.get("image_url"))
                            })
                except Exception as e:
                    print(f"Error fetching creative {creative_id}: {e}")
        
        return patterns
    
    async def learn_from_ads(self, user_id: str, access_token: str, ad_account_id: str) -> Dict:
        """التعلم الكامل من إعلانات المستخدم"""
        result = {
            "success": False,
            "ads_analyzed": 0,
            "patterns_learned": 0,
            "insights": {},
            "recommendations": []
        }
        
        try:
            ads = await self.fetch_user_ads(access_token, ad_account_id)
            
            if not ads:
                result["message"] = "لم يتم العثور على إعلانات"
                return result
            
            analysis = await self.analyze_ad_performance(ads)
            result["ads_analyzed"] = analysis["total_ads"]
            
            if analysis["successful_ads"]:
                patterns = await self.extract_winning_patterns(analysis["successful_ads"], access_token)
                result["patterns_learned"] = len(patterns)
                
                self.learned_patterns[user_id] = {
                    "patterns": patterns,
                    "analysis": analysis,
                    "learned_at": datetime.now().isoformat()
                }
                
                result["insights"] = await self._generate_ai_insights(patterns, analysis)
            
            result["success"] = True
            result["message"] = f"تم تحليل {result['ads_analyzed']} إعلان وتعلم {result['patterns_learned']} نمط ناجح"
            
        except Exception as e:
            result["error"] = str(e)
            result["message"] = f"خطأ في التعلم: {str(e)}"
        
        return result
    
    async def _generate_ai_insights(self, patterns: List[Dict], analysis: Dict) -> Dict:
        """توليد رؤى ذكية باستخدام AI"""
        if not self.openai_client or not patterns:
            return self._generate_basic_insights(patterns, analysis)
        
        try:
            patterns_text = json.dumps(patterns[:5], ensure_ascii=False, indent=2)
            
            response = self.openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {
                        "role": "system",
                        "content": """أنت خبير إعلانات فيسبوك. حلل الإعلانات الناجحة واستخرج:
1. العناوين الأكثر جذباً
2. أنماط النص الفعالة
3. أفضل CTAs
4. توصيات للإعلانات الجديدة

رد بـ JSON فقط."""
                    },
                    {
                        "role": "user",
                        "content": f"إعلانات ناجحة للتحليل:\n{patterns_text}"
                    }
                ],
                max_tokens=1000
            )
            
            content = response.choices[0].message.content
            try:
                return json.loads(content)
            except:
                return {"raw_insights": content}
                
        except Exception as e:
            print(f"AI insights error: {e}")
            return self._generate_basic_insights(patterns, analysis)
    
    def _generate_basic_insights(self, patterns: List[Dict], analysis: Dict) -> Dict:
        """رؤى أساسية بدون AI"""
        insights = {
            "top_headlines": [],
            "effective_ctas": [],
            "content_type": {"video": 0, "image": 0},
            "average_performance": {
                "ctr": analysis.get("average_ctr", 0),
                "cpc": analysis.get("average_cpc", 0)
            }
        }
        
        for p in patterns:
            if p.get("headline"):
                insights["top_headlines"].append(p["headline"])
            if p.get("cta"):
                insights["effective_ctas"].append(p["cta"])
            if p.get("has_video"):
                insights["content_type"]["video"] += 1
            if p.get("has_image"):
                insights["content_type"]["image"] += 1
        
        return insights
    
    def get_learned_patterns(self, user_id: str) -> Optional[Dict]:
        """الحصول على الأنماط المتعلمة لمستخدم"""
        return self.learned_patterns.get(user_id)
    
    def apply_patterns_to_new_ad(self, user_id: str, ad_content: Dict) -> Dict:
        """تطبيق الأنماط المتعلمة على إعلان جديد"""
        patterns = self.get_learned_patterns(user_id)
        
        if not patterns:
            return ad_content
        
        enhanced = ad_content.copy()
        
        learned = patterns.get("patterns", [])
        if learned:
            best = max(learned, key=lambda x: x.get("ctr", 0))
            
            if not enhanced.get("headline") and best.get("headline"):
                enhanced["headline_inspiration"] = best["headline"]
            
            if not enhanced.get("cta") and best.get("cta"):
                enhanced["recommended_cta"] = best["cta"]
            
            enhanced["learning_applied"] = True
            enhanced["based_on_ad"] = best.get("ad_name")
        
        return enhanced


ad_learning_service = AdLearningService()
