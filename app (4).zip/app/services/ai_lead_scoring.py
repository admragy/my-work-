"""
AI Lead Scoring Service - Automatic lead scoring using AI
Scores leads as: hot (80-100), warm (50-79), cold (0-49)
"""
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import json


class LeadScorer:
    """AI-powered lead scoring system"""
    
    SCORING_FACTORS = {
        "has_phone": 15,
        "has_email": 10,
        "has_both": 10,
        "from_ads": 20,
        "replied": 25,
        "interested": 15,
        "recent_activity": 10,
        "multiple_interactions": 15,
        "high_value_source": 10,
    }
    
    STAGE_SCORES = {
        "new": 20,
        "bait_sent": 30,
        "replied": 50,
        "interested": 70,
        "negotiating": 80,
        "hot": 95,
        "closed": 100,
        "lost": 5,
    }
    
    SOURCE_MULTIPLIERS = {
        "ads_facebook": 1.3,
        "ads_google": 1.2,
        "ads_tiktok": 1.1,
        "referral": 1.4,
        "manual": 1.0,
        "import": 0.9,
    }
    
    @classmethod
    def calculate_score(cls, lead: Dict) -> Dict:
        """Calculate lead score with breakdown"""
        score = 0
        factors = []
        
        has_phone = bool(lead.get("phone"))
        has_email = bool(lead.get("email"))
        if has_phone:
            score += cls.SCORING_FACTORS["has_phone"]
            factors.append(("رقم موبايل", cls.SCORING_FACTORS["has_phone"]))
        if has_email:
            score += cls.SCORING_FACTORS["has_email"]
            factors.append(("إيميل", cls.SCORING_FACTORS["has_email"]))
        if has_phone and has_email:
            score += cls.SCORING_FACTORS["has_both"]
            factors.append(("بيانات كاملة", cls.SCORING_FACTORS["has_both"]))
        
        source = lead.get("source", "manual")
        if "ads" in source.lower():
            score += cls.SCORING_FACTORS["from_ads"]
            factors.append(("من إعلان", cls.SCORING_FACTORS["from_ads"]))
        
        status = lead.get("status", "new")
        stage_score = cls.STAGE_SCORES.get(status, 20)
        score = max(score, stage_score)
        factors.append((f"مرحلة: {status}", stage_score))
        
        multiplier = 1.0
        for src_key, mult in cls.SOURCE_MULTIPLIERS.items():
            if src_key in source.lower():
                multiplier = mult
                break
        
        final_score = min(100, int(score * multiplier))
        
        if final_score >= 80:
            label = "hot"
            label_ar = "🔥 ساخن"
            color = "red"
        elif final_score >= 50:
            label = "warm"
            label_ar = "🌡️ دافئ"
            color = "orange"
        else:
            label = "cold"
            label_ar = "❄️ بارد"
            color = "blue"
        
        return {
            "score": final_score,
            "label": label,
            "label_ar": label_ar,
            "color": color,
            "factors": factors,
            "recommendation": cls.get_recommendation(final_score, status)
        }
    
    @classmethod
    def get_recommendation(cls, score: int, status: str) -> str:
        """Get AI recommendation for next action"""
        if score >= 80:
            return "⚡ تواصل فوراً! عميل جاهز للشراء"
        elif score >= 70:
            return "📞 اتصل خلال ساعة - عميل مهتم جداً"
        elif score >= 50:
            return "💬 ابعت رسالة متابعة على الواتساب"
        elif score >= 30:
            return "📧 ابعت عرض مغري بخصم"
        else:
            return "🎯 ضيفه لحملة ريتارجتنج"
    
    @classmethod
    def score_leads_batch(cls, leads: List[Dict]) -> List[Dict]:
        """Score multiple leads"""
        scored = []
        for lead in leads:
            lead_copy = lead.copy()
            scoring = cls.calculate_score(lead)
            lead_copy["ai_score"] = scoring["score"]
            lead_copy["ai_label"] = scoring["label"]
            lead_copy["ai_label_ar"] = scoring["label_ar"]
            lead_copy["ai_color"] = scoring["color"]
            lead_copy["ai_recommendation"] = scoring["recommendation"]
            scored.append(lead_copy)
        
        scored.sort(key=lambda x: x.get("ai_score", 0), reverse=True)
        return scored
    
    @classmethod
    def get_insights(cls, leads: List[Dict]) -> Dict:
        """Get AI insights from leads"""
        if not leads:
            return {
                "total": 0,
                "hot": 0,
                "warm": 0,
                "cold": 0,
                "avg_score": 0,
                "top_sources": [],
                "recommendations": []
            }
        
        scored = cls.score_leads_batch(leads)
        
        hot = sum(1 for l in scored if l.get("ai_label") == "hot")
        warm = sum(1 for l in scored if l.get("ai_label") == "warm")
        cold = sum(1 for l in scored if l.get("ai_label") == "cold")
        avg_score = sum(l.get("ai_score", 0) for l in scored) // len(scored)
        
        sources = {}
        for l in scored:
            src = l.get("source", "unknown")
            if src not in sources:
                sources[src] = {"count": 0, "total_score": 0}
            sources[src]["count"] += 1
            sources[src]["total_score"] += l.get("ai_score", 0)
        
        top_sources = []
        for src, data in sorted(sources.items(), key=lambda x: x[1]["total_score"], reverse=True)[:3]:
            avg = data["total_score"] // data["count"] if data["count"] > 0 else 0
            top_sources.append({"source": src, "count": data["count"], "avg_score": avg})
        
        recommendations = []
        if hot > 0:
            recommendations.append(f"🔥 عندك {hot} عميل ساخن - تواصل معاهم فوراً!")
        if warm > hot:
            recommendations.append(f"🌡️ {warm} عميل دافئ - ابعتلهم عروض مغرية")
        if cold > warm + hot:
            recommendations.append(f"❄️ {cold} عميل بارد - فعّل حملة ريتارجتنج")
        if avg_score < 40:
            recommendations.append("⚠️ جودة العملاء منخفضة - راجع استهداف الإعلانات")
        if avg_score > 60:
            recommendations.append("✅ جودة العملاء ممتازة - زود الميزانية!")
        
        return {
            "total": len(leads),
            "hot": hot,
            "warm": warm,
            "cold": cold,
            "avg_score": avg_score,
            "top_sources": top_sources,
            "recommendations": recommendations,
            "scored_leads": scored[:10]
        }


class NextActionPredictor:
    """AI-powered next best action predictor"""
    
    ACTIONS = {
        "call_now": {"ar": "اتصل الآن", "icon": "📞", "priority": 1},
        "whatsapp_followup": {"ar": "متابعة واتساب", "icon": "💬", "priority": 2},
        "send_offer": {"ar": "ابعت عرض", "icon": "🎁", "priority": 3},
        "schedule_meeting": {"ar": "حدد موعد", "icon": "📅", "priority": 4},
        "add_to_campaign": {"ar": "ضيف لحملة", "icon": "🎯", "priority": 5},
        "wait": {"ar": "انتظر", "icon": "⏰", "priority": 6},
    }
    
    @classmethod
    def predict(cls, lead: Dict, score: int) -> Dict:
        """Predict next best action for a lead"""
        status = lead.get("status", "new")
        
        if score >= 80:
            action = "call_now"
        elif status == "replied":
            action = "send_offer"
        elif status == "interested":
            action = "schedule_meeting"
        elif score >= 50:
            action = "whatsapp_followup"
        elif score >= 30:
            action = "send_offer"
        else:
            action = "add_to_campaign"
        
        action_data = cls.ACTIONS.get(action, cls.ACTIONS["wait"])
        
        return {
            "action": action,
            "action_ar": action_data["ar"],
            "icon": action_data["icon"],
            "priority": action_data["priority"],
            "full_text": f"{action_data['icon']} {action_data['ar']}"
        }
