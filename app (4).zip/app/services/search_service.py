"""
Search Service
Enhanced hybrid search with Golden Query optimization for cost efficiency
"""
import re
from typing import List, Dict, Optional
import requests
from app.core.config import settings
from app.services.ai_service import AIService


class SearchService:
    """Enhanced hybrid search service"""
    
    @staticmethod
    def search_serper(query: str, max_results: int = 20) -> List[Dict]:
        """Search using Serper API"""
        if not settings.SERPER_API_KEY:
            return []
        
        try:
            response = requests.post(
                "https://google.serper.dev/search",
                headers={
                    "X-API-KEY": settings.SERPER_API_KEY,
                    "Content-Type": "application/json"
                },
                json={
                    "q": query,
                    "gl": "eg",
                    "hl": "ar",
                    "num": max_results
                },
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                results = []
                
                for item in data.get("organic", [])[:max_results]:
                    results.append({
                        "title": item.get("title", ""),
                        "link": item.get("link", ""),
                        "snippet": item.get("snippet", ""),
                        "source": "serper"
                    })
                
                return results
        except Exception as e:
            print(f"Serper error: {e}")
        
        return []
    
    @staticmethod
    def search_duckduckgo(query: str, max_results: int = 20) -> List[Dict]:
        """Search using DuckDuckGo (fallback)"""
        try:
            response = requests.get(
                "https://api.duckduckgo.com/",
                params={
                    "q": query,
                    "format": "json",
                    "no_redirect": 1,
                    "no_html": 1
                },
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                results = []
                
                for item in data.get("RelatedTopics", [])[:max_results]:
                    if "Text" in item:
                        results.append({
                            "title": item.get("Text", "")[:100],
                            "link": item.get("FirstURL", ""),
                            "snippet": item.get("Text", ""),
                            "source": "duckduckgo"
                        })
                
                return results
        except Exception as e:
            print(f"DuckDuckGo error: {e}")
        
        return []
    
    @classmethod
    def search(cls, query: str, max_results: int = 20) -> List[Dict]:
        """Search with fallback chain"""
        results = cls.search_serper(query, max_results)
        
        if not results:
            results = cls.search_duckduckgo(query, max_results)
        
        return results
    
    PHONE_PATTERNS_BY_COUNTRY = {
        "egypt": [
            r'(?:\+?2)?01[0125]\d{8}',
            r'01[0125]\d{8}',
            r'01[0125][-\s]?\d{4}[-\s]?\d{4}',
            r'\+20\s?1[0125]\d{8}',
        ],
        "saudi": [
            r'(?:\+?966)?0?5[0-9]\d{7}',
            r'05[0-9]\d{7}',
            r'05[0-9][-\s]?\d{3}[-\s]?\d{4}',
            r'\+966\s?5[0-9]\d{7}',
            r'9665[0-9]\d{7}',
        ],
        "uae": [
            r'(?:\+?971)?0?5[0-9]\d{7}',
            r'05[0-9]\d{7}',
            r'\+971\s?5[0-9]\d{7}',
            r'9715[0-9]\d{7}',
        ],
        "kuwait": [
            r'(?:\+?965)?[569]\d{7}',
            r'[569]\d{7}',
            r'\+965\s?[569]\d{7}',
        ],
        "all": [
            r'(?:\+?2)?01[0125]\d{8}',
            r'01[0125]\d{8}',
            r'(?:\+?966)?0?5[0-9]\d{7}',
            r'05[0-9]\d{7}',
            r'(?:\+?971)?0?5[0-9]\d{7}',
            r'(?:\+?965)?[569]\d{7}',
        ]
    }
    
    CUSTOMER_INTENT_KEYWORDS = [
        "محتاج", "عايز", "ابحث عن", "مين يعرف", "دلوني على",
        "يا ريت حد", "حد يرشحلي", "حد يعرف", "تجربتكم مع", "حد جرب"
    ]
    
    @classmethod
    def extract_leads_from_results(cls, results: List[Dict], country: str = "all", include_no_phone: bool = True) -> List[Dict]:
        """Extract potential leads from search results - includes customers without phone if they show intent"""
        leads = []
        seen_phones = set()
        seen_urls = set()
        
        phone_patterns = cls.PHONE_PATTERNS_BY_COUNTRY.get(country, cls.PHONE_PATTERNS_BY_COUNTRY["all"])
        if country != "all":
            phone_patterns = phone_patterns + cls.PHONE_PATTERNS_BY_COUNTRY["all"]
        
        email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        
        for result in results:
            text = f"{result.get('title', '')} {result.get('snippet', '')}"
            url = result.get("link", "")
            
            phones = []
            for pattern in phone_patterns:
                matches = re.findall(pattern, text)
                for match in matches:
                    clean_phone = re.sub(r'[\s\-]', '', match)
                    if len(clean_phone) >= 8 and clean_phone not in seen_phones:
                        phones.append(clean_phone)
                        seen_phones.add(clean_phone)
            
            emails = re.findall(email_pattern, text)
            
            has_customer_intent = any(kw in text for kw in cls.CUSTOMER_INTENT_KEYWORDS)
            
            should_include = phones or emails or (include_no_phone and has_customer_intent and url not in seen_urls)
            
            if should_include:
                name = result.get("title", "عميل محتمل")
                name = re.sub(r'\s*[-|–]\s*.*', '', name)[:60]
                
                detected_country = cls._detect_phone_country(phones[0]) if phones else country
                
                lead_type = "with_phone" if phones else ("with_email" if emails else "potential")
                
                leads.append({
                    "name": name,
                    "phone": phones[0] if phones else "",
                    "email": emails[0] if emails else "",
                    "source": url,
                    "notes": result.get("snippet", "")[:300],
                    "status": "new",
                    "country": detected_country,
                    "lead_type": lead_type
                })
                seen_urls.add(url)
        
        return leads
    
    @staticmethod
    def _detect_phone_country(phone: str) -> str:
        """Detect country from phone number format"""
        if not phone:
            return "unknown"
        
        clean = re.sub(r'[\s\-\+]', '', phone)
        
        if clean.startswith('20') or clean.startswith('01'):
            return "egypt"
        elif clean.startswith('966') or clean.startswith('05'):
            return "saudi"
        elif clean.startswith('971') or (clean.startswith('05') and len(clean) == 10):
            return "uae"
        elif clean.startswith('965'):
            return "kuwait"
        
        return "unknown"
    
    @classmethod
    def search_with_country(cls, query: str, country: str = "egypt", max_results: int = 20) -> List[Dict]:
        """Search with country-specific settings"""
        country_gl = {
            "egypt": "eg",
            "saudi": "sa", 
            "uae": "ae",
            "kuwait": "kw"
        }
        gl = country_gl.get(country, "eg")
        
        if settings.SERPER_API_KEY:
            try:
                response = requests.post(
                    "https://google.serper.dev/search",
                    headers={
                        "X-API-KEY": settings.SERPER_API_KEY,
                        "Content-Type": "application/json"
                    },
                    json={
                        "q": query,
                        "gl": gl,
                        "hl": "ar",
                        "num": max_results
                    },
                    timeout=10
                )
                
                if response.status_code == 200:
                    data = response.json()
                    results = []
                    for item in data.get("organic", [])[:max_results]:
                        results.append({
                            "title": item.get("title", ""),
                            "link": item.get("link", ""),
                            "snippet": item.get("snippet", ""),
                            "source": "serper"
                        })
                    return results
            except Exception as e:
                print(f"Serper error: {e}")
        
        return cls.search_duckduckgo(query, max_results)
    
    @classmethod
    def hunt_leads(cls, query: str, city: str = "القاهرة", max_results: int = 20, 
                   strategy: str = "social_media", country: Optional[str] = None) -> List[Dict]:
        """Hunt for leads - FAST version with parallel queries"""
        all_leads = []
        seen_phones = set()
        seen_urls = set()
        
        if not country:
            country = AIService.detect_country(city)
        
        service = AIService._extract_service(query)
        
        high_quality_queries = [
            f'{service} {city} للتواصل',
            f'{service} {city} رقم تليفون',
            f'{service} {city} واتساب',
            f'{service} {city} موبايل',
            f'{service} {city} احجز',
            f'محتاج {service} {city}',
            f'عايز {service} {city}',
            f'دلوني على {service} {city}',
            f'مين يعرف {service} {city}',
            f'{service} {city}',
        ]
        
        print(f"🚀 Starting hunt for '{service}' in {city} ({country})")
        
        for i, search_query in enumerate(high_quality_queries):
            if len(all_leads) >= max_results:
                break
            
            print(f"🔍 Query {i+1}/{len(high_quality_queries)}: {search_query[:50]}...")
            results = cls.search_with_country(search_query, country, 100)
            
            if not results:
                continue
                
            leads = cls.extract_leads_from_results(results, country, include_no_phone=True)
            
            for lead in leads:
                if len(all_leads) >= max_results:
                    break
                    
                phone = lead.get('phone', '')
                url = lead.get('source', '')
                
                if phone:
                    if phone not in seen_phones:
                        all_leads.append(lead)
                        seen_phones.add(phone)
                elif url and url not in seen_urls:
                    all_leads.append(lead)
                    seen_urls.add(url)
        
        return all_leads[:max_results]
