"""Image Optimizer Service - Auto-fix images for Facebook Ads"""
import os
import base64
from io import BytesIO
from typing import Dict, Any, Optional, Tuple
from PIL import Image

class ImageOptimizerService:
    """Auto-optimize images for Facebook Ads requirements"""
    
    FORMATS = {
        'feed_square': (1080, 1080),
        'feed_landscape': (1200, 628),
        'feed_portrait': (1080, 1350),
        'story': (1080, 1920),
        'carousel': (1080, 1080),
    }
    
    MAX_FILE_SIZE_MB = 30
    QUALITY_START = 85
    MIN_WIDTH = 600
    MIN_HEIGHT = 600
    
    def __init__(self):
        self.upload_dir = "uploads/optimized"
        os.makedirs(self.upload_dir, exist_ok=True)
    
    def optimize_image(
        self,
        image_data: bytes,
        target_format: str = 'feed_square',
        quality: int = 85
    ) -> Dict[str, Any]:
        """Optimize image for Facebook Ads"""
        try:
            img = Image.open(BytesIO(image_data))
            
            original_size = len(image_data)
            original_mode = img.mode
            original_dimensions = img.size
            
            issues_fixed = []
            
            if img.mode in ('RGBA', 'LA', 'P'):
                background = Image.new('RGB', img.size, (255, 255, 255))
                if img.mode == 'RGBA':
                    background.paste(img, mask=img.split()[-1])
                else:
                    background.paste(img)
                img = background
                issues_fixed.append("تم تحويل الصورة الشفافة لـ RGB")
            elif img.mode != 'RGB':
                img = img.convert('RGB')
                issues_fixed.append(f"تم تحويل من {original_mode} لـ RGB")
            
            target_size = self.FORMATS.get(target_format, self.FORMATS['feed_square'])
            
            if img.width < self.MIN_WIDTH or img.height < self.MIN_HEIGHT:
                scale = max(self.MIN_WIDTH / img.width, self.MIN_HEIGHT / img.height)
                new_size = (int(img.width * scale), int(img.height * scale))
                img = img.resize(new_size, Image.Resampling.LANCZOS)
                issues_fixed.append(f"تم تكبير الصورة من {original_dimensions[0]}x{original_dimensions[1]}")
            
            img = self._smart_crop(img, target_size)
            issues_fixed.append(f"تم تعديل الأبعاد لـ {target_size[0]}x{target_size[1]}")
            
            output = BytesIO()
            img.save(output, 'JPEG', optimize=True, quality=quality, progressive=True)
            optimized_data = output.getvalue()
            
            max_bytes = self.MAX_FILE_SIZE_MB * 1024 * 1024
            current_quality = quality
            while len(optimized_data) > max_bytes and current_quality > 50:
                current_quality -= 5
                output = BytesIO()
                img.save(output, 'JPEG', optimize=True, quality=current_quality, progressive=True)
                optimized_data = output.getvalue()
            
            if len(optimized_data) < original_size:
                compression_percent = round((1 - len(optimized_data) / original_size) * 100, 1)
                issues_fixed.append(f"تم ضغط الصورة {compression_percent}%")
            
            return {
                "success": True,
                "optimized_data": optimized_data,
                "optimized_base64": base64.b64encode(optimized_data).decode(),
                "original_size": original_size,
                "new_size": len(optimized_data),
                "dimensions": target_size,
                "format": "JPEG",
                "quality": current_quality,
                "issues_fixed": issues_fixed,
                "ready_for_facebook": True
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "ready_for_facebook": False
            }
    
    def _smart_crop(self, img: Image.Image, target_size: Tuple[int, int]) -> Image.Image:
        """Smart crop to maintain focus on center"""
        img_ratio = img.width / img.height
        target_ratio = target_size[0] / target_size[1]
        
        if abs(img_ratio - target_ratio) < 0.01:
            return img.resize(target_size, Image.Resampling.LANCZOS)
        
        if img_ratio > target_ratio:
            new_width = int(img.height * target_ratio)
            left = (img.width - new_width) // 2
            img = img.crop((left, 0, left + new_width, img.height))
        else:
            new_height = int(img.width / target_ratio)
            top = (img.height - new_height) // 2
            img = img.crop((0, top, img.width, top + new_height))
        
        return img.resize(target_size, Image.Resampling.LANCZOS)
    
    def optimize_for_all_formats(self, image_data: bytes) -> Dict[str, Any]:
        """Generate optimized versions for all Facebook formats"""
        results = {}
        
        for format_name, dimensions in self.FORMATS.items():
            result = self.optimize_image(image_data, format_name)
            if result["success"]:
                results[format_name] = {
                    "dimensions": dimensions,
                    "size": result["new_size"],
                    "base64": result["optimized_base64"][:100] + "...",
                    "ready": True
                }
        
        return {
            "success": True,
            "formats": results,
            "recommended": "feed_square"
        }
    
    def save_optimized_image(
        self,
        user_id: str,
        image_data: bytes,
        target_format: str = 'feed_square'
    ) -> Dict[str, Any]:
        """Optimize and save image to disk"""
        result = self.optimize_image(image_data, target_format)
        
        if not result["success"]:
            return result
        
        from datetime import datetime
        filename = f"{user_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}_{target_format}.jpg"
        filepath = os.path.join(self.upload_dir, filename)
        
        with open(filepath, 'wb') as f:
            f.write(result["optimized_data"])
        
        result["filepath"] = filepath
        result["filename"] = filename
        
        return result
    
    def check_image_issues(self, image_data: bytes) -> Dict[str, Any]:
        """Check image for potential issues without modifying"""
        try:
            img = Image.open(BytesIO(image_data))
            
            issues = []
            warnings = []
            
            if img.mode in ('RGBA', 'LA', 'P'):
                issues.append("الصورة شفافة - هيتم تحويلها")
            
            if img.width < self.MIN_WIDTH or img.height < self.MIN_HEIGHT:
                issues.append(f"الصورة صغيرة ({img.width}x{img.height}) - الحد الأدنى 600x600")
            
            file_size_mb = len(image_data) / (1024 * 1024)
            if file_size_mb > 10:
                warnings.append(f"حجم الصورة كبير ({file_size_mb:.1f}MB) - هيتم ضغطها")
            
            if file_size_mb > self.MAX_FILE_SIZE_MB:
                issues.append(f"الصورة أكبر من {self.MAX_FILE_SIZE_MB}MB")
            
            img_ratio = img.width / img.height
            if img_ratio < 0.5 or img_ratio > 2:
                warnings.append("نسبة الأبعاد غريبة - هيتم تعديلها تلقائياً")
            
            return {
                "can_fix": True,
                "issues": issues,
                "warnings": warnings,
                "original_dimensions": img.size,
                "original_mode": img.mode,
                "file_size_mb": round(file_size_mb, 2)
            }
            
        except Exception as e:
            return {
                "can_fix": False,
                "error": f"الملف مش صورة صالحة: {str(e)}"
            }


image_optimizer_service = ImageOptimizerService()
