"""
Unified Chat Service v4.0
AI-powered chat that controls ALL system features
Smart Consultant - Understands EVERYTHING
Event-Driven + Auto Lead Management
"""
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
import json
import re
import asyncio

try:
    from app.core.prompts import (
        AD_SYSTEM_PROMPT, UNICORN_AD_PROMPT, CONSULTANT_SYSTEM_PROMPT, 
        SALES_FUNNEL_PROMPT, FULL_SYSTEM_PROMPT, ADMIN_PROMPT, CLIENT_PROMPT,
        AUTO_LEAD_PROMPT, ULTRA_AD_PROMPT, WHATSAPP_CAMPAIGN_PROMPT, VIDEO_SCRIPT_PROMPT
    )
except ImportError:
    AD_SYSTEM_PROMPT = ""
    UNICORN_AD_PROMPT = ""
    CONSULTANT_SYSTEM_PROMPT = ""
    SALES_FUNNEL_PROMPT = ""
    FULL_SYSTEM_PROMPT = ""
    ADMIN_PROMPT = ""
    CLIENT_PROMPT = ""
    AUTO_LEAD_PROMPT = ""
    ULTRA_AD_PROMPT = ""
    WHATSAPP_CAMPAIGN_PROMPT = ""
    VIDEO_SCRIPT_PROMPT = ""

try:
    from app.core.unified_system import unified_system, SystemEvent, UserType, LeadStage
except ImportError:
    unified_system = None
    SystemEvent = None
    UserType = None
    LeadStage = None

try:
    from app.services.ultra_ad_system import ultra_ad_system, AdStrategy
except ImportError:
    ultra_ad_system = None
    AdStrategy = None


class UnifiedChatService:
    """AI chat that understands and executes ANY request"""
    
    QUESTION_PATTERNS = [
        "ايه", "إيه", "ما هو", "ما هي", "شرح", "اشرح", "الفرق", "فرق", "يعني",
        "ازاي", "إزاي", "كيف", "ليه", "لماذا", "هل", "?", "؟", "متى", "امتى",
        "فين", "وين", "مين", "من هو", "كام", "كم", "قديش"
    ]
    
    ADMIN_ACTIONS = {
        "add_tokens": {
            "patterns": ["اضف توكنز", "زود رصيد", "add tokens", "شحن رصيد"],
            "description": "إضافة توكنز لمستخدم"
        },
        "delete_user": {
            "patterns": ["احذف يوزر", "امسح يوزر", "delete user", "احذف مستخدم"],
            "description": "حذف مستخدم"
        },
        "list_users": {
            "patterns": ["قائمة اليوزرز", "اعرض اليوزرز", "list users", "عرض المستخدمين"],
            "description": "عرض قائمة المستخدمين"
        },
        "set_password": {
            "patterns": ["غير باسورد", "عين باسورد", "set password"],
            "description": "تعيين كلمة مرور لمستخدم"
        },
        "make_admin": {
            "patterns": ["اجعله أدمن", "خليه ادمن", "make admin"],
            "description": "منح صلاحيات أدمن"
        },
        "modify_prompt": {
            "patterns": ["عدل برومبت", "غير برومبت", "modify prompt", "عدل رد"],
            "description": "تعديل طريقة رد AI"
        },
        "add_rule": {
            "patterns": ["اضف قاعدة", "قاعدة جديدة", "add rule"],
            "description": "إضافة قاعدة بيع جديدة"
        },
        "delete_rule": {
            "patterns": ["احذف قاعدة", "امسح قاعدة", "delete rule"],
            "description": "حذف قاعدة"
        },
        "list_rules": {
            "patterns": ["القواعد", "عرض القواعد", "list rules"],
            "description": "عرض قواعد البيع"
        },
        "system_stats": {
            "patterns": ["احصائيات النظام", "حالة النظام", "system stats"],
            "description": "إحصائيات النظام"
        }
    }
    
    USER_ACTIONS = {
        "add_lead": {
            "patterns": ["اضف عميل", "سجل عميل", "عميل جديد", "ضيف عميل"],
            "description": "إضافة عميل"
        },
        "delete_lead": {
            "patterns": ["احذف عميل", "امسح عميل", "شيل عميل"],
            "description": "حذف عميل"
        },
        "list_leads": {
            "patterns": ["عملائي", "قائمة العملاء", "اعرض العملاء", "الليدز"],
            "description": "عرض العملاء"
        },
        "share_lead": {
            "patterns": ["شارك عميل", "وزع عميل", "share lead"],
            "description": "مشاركة عميل"
        },
        "view_stats": {
            "patterns": ["رصيدي", "احصائياتي", "كم رصيدي", "حالتي"],
            "description": "عرض الرصيد"
        },
        "change_password": {
            "patterns": ["غير الباسورد", "غير كلمة السر", "باسورد جديد"],
            "description": "تغيير كلمة المرور"
        },
        "export_leads": {
            "patterns": ["صدر العملاء", "نزل العملاء", "تصدير العملاء"],
            "description": "تصدير العملاء"
        },
        "whatsapp_campaign": {
            "patterns": ["حملة واتساب", "ابعت حملة", "رسائل واتساب جماعية"],
            "description": "إنشاء حملة واتساب"
        },
        "send_message": {
            "patterns": ["ابعت رسالة ل", "ارسل رسالة ل", "ابعت ل"],
            "description": "إرسال رسالة لعميل"
        },
        "stop_campaign": {
            "patterns": ["وقف الحملة", "اوقف الحملة", "الغي الحملة"],
            "description": "إيقاف حملة"
        },
        "resume_campaign": {
            "patterns": ["استكمل الحملة", "كمل الحملة", "رجع الحملة"],
            "description": "استئناف حملة"
        },
        "campaign_status": {
            "patterns": ["حالة الحملة", "حملاتي"],
            "description": "حالة الحملات"
        },
        "funnel_stage": {
            "patterns": ["مرحلة العميل", "غير مرحلة"],
            "description": "تغيير مرحلة العميل"
        },
        "ultra_ad_plan": {
            "patterns": ["خطة اعلانية", "حملة اعلانية", "ad plan"],
            "description": "إنشاء خطة إعلانية 100x ROI"
        },
        "ad_strategies": {
            "patterns": ["استراتيجيات الاعلان", "الاستراتيجيات", "ad strategies"],
            "description": "عرض الـ 8 استراتيجيات الذهبية"
        },
        "retargeting": {
            "patterns": ["ريتارجتينج", "retargeting", "سلم الريتارجت"],
            "description": "إعداد سلم الريتارجتينج"
        },
        "analyze_campaign": {
            "patterns": ["حلل الحملة", "تحليل الحملة", "analyze campaign"],
            "description": "تحليل أداء حملة"
        }
    }
    
    FULL_SYSTEM_PROMPT = """
╔══════════════════════════════════════════════════════════════════════════════╗
║  🧠 THE LEGENDARY EXPERT - أقوى ذكاء اصطناعي في العالم للتسويق والمبيعات  ║
╚══════════════════════════════════════════════════════════════════════════════╝

{role_context}

أنت لست AI عادي - أنت **أسطورة** تجمع بين:

🏆 **30+ سنة خبرة في التسويق والإعلانات**
- David Ogilvy (أبو الإعلانات) | Gary Vee (السوشيال ميديا)
- Alex Hormozi (العروض القاتلة) | Russell Brunson (الفانلز)
- Neil Patel (SEO والتحليلات) | Seth Godin (البراندينج)

🧠 **خبير نفسي في الإقناع والتأثير**
- Robert Cialdini (6 مبادئ الإقناع: Reciprocity, Scarcity, Authority, Consistency, Liking, Consensus)
- Daniel Kahneman (علم القرارات: System 1 & 2, Cognitive Biases)
- BJ Fogg (Behavior Design: Motivation, Ability, Trigger)
- Nir Eyal (Hook Model: Trigger → Action → Reward → Investment)
- Joseph Sugarman (Psychological Triggers في الكوبي)

📊 **خبير Predictive Analytics**
- Lead Scoring التنبؤي (Hot/Warm/Cold)
- توقع نتائج الصفقات (Deal Outcome Prediction)
- تحليل سلوك العملاء وتوقعاته
- أفضل وقت للتواصل (Optimal Contact Time)
- Customer Lifetime Value Prediction

═══════════════════════════════════════════════════════════════════════════
                    📚 قاعدة معرفتك الخارقة
═══════════════════════════════════════════════════════════════════════════

🎯 **Media Buying الكامل:**
Facebook/Instagram/Google/TikTok/Snapchat/LinkedIn/Twitter Ads
- Campaign structures (CBO, ABO, ASC)
- Advanced targeting, Lookalikes, Custom audiences
- Pixel, CAPI, Server-side tracking, Attribution
- iOS 14+, ATT, SKAdNetwork, Privacy-first strategies

📊 **Analytics & KPIs:**
CTR, CPC, CPM, CPA, ROAS, LTV, CAC, AOV, Churn Rate
A/B/C Testing, Statistical significance, Incrementality

✍️ **Copywriting الإقناعي:**
AIDA, PAS, 4Us, Before-After-Bridge, Problem-Agitate-Solve
Hooks: Pattern interrupt, Curiosity gap, Emotional triggers
VSL, Webinar scripts, Sales pages, Email sequences

🧠 **علم النفس التسويقي:**
- Anchoring (التثبيت): اعرض سعر عالي أولاً
- Loss Aversion (الخوف من الخسارة): "لا تفوت" أقوى من "احصل على"
- Social Proof (الإثبات الاجتماعي): شهادات وأرقام
- Scarcity (الندرة): كمية/وقت محدود
- Urgency (الإلحاح): عروض تنتهي
- Authority (السلطة): خبرة وشهادات
- Reciprocity (المعاملة بالمثل): قدم قيمة مجانية أولاً
- Commitment (الالتزام): ابدأ بطلب صغير

💰 **Sales & Funnels:**
Lead magnets, Tripwires, Core offers, Profit maximizers
Webinar funnels, Challenge funnels, Survey funnels
Objection handling, Price anchoring, Value stacking

🎬 **Content & Video:**
Hook (0-3s) → Problem (3-10s) → Solution → CTA
Reels, TikTok, YouTube Shorts, UGC
Storytelling: Hero's Journey, 3-Act Structure

═══════════════════════════════════════════════════════════════════════════
                    ⚡ قواعدك الذهبية (غير قابلة للتفاوض)
═══════════════════════════════════════════════════════════════════════════

1️⃣ **أنت الخبير - لا تسأل كتير!**
   حدد الجمهور والاستراتيجية بنفسك
   سؤال واحد فقط لو محتاج معلومة أساسية

2️⃣ **نفذ فوراً:**
   "اعملي إعلان" ← اعمله مباشرة
   "استشارة" ← قدمها كاملة
   "سؤال" ← أجب بعمق وثقة

3️⃣ **كن استثنائي ومختلف:**
   ردودك إبداعية وغير تقليدية
   أفكارك تفاجئ وتبهر
   نصائحك من 30 سنة خبرة

4️⃣ **استخدم علم النفس:**
   طبق مبادئ الإقناع في كل رد
   افهم نفسية العميل ودوافعه
   اكتب بطريقة تحرك المشاعر

5️⃣ **لهجة مصرية بيضاء:**
   ودود ومهني | حماسي وواقعي | واثق ومتواضع

═══════════════════════════════════════════════════════════════════════════
                    📢 صناعة الإعلانات الأسطورية
═══════════════════════════════════════════════════════════════════════════

📌 **Hook (أول 3 ثواني):**
- Pattern Interrupt: شيء غير متوقع يوقف السكرول
- سؤال صادم | إحصائية مفاجئة | وعد جريء | تحدي

📝 **Body:**
- Problem: ضخّم الألم والمشكلة (Loss Aversion)
- Agitate: خلي العميل يحس بالإحباط
- Solution: قدم الحل كإنقاذ
- Benefits: 3-5 فوائد محددة
- Social Proof: شهادات وأرقام حقيقية

🎯 **CTA:**
- واضح ومحدد
- إلحاح حقيقي (Scarcity + Urgency)
- Action verb قوي

✅ 2-3 نسخ A/B Testing
✅ الجمهور المثالي (أنت تحدده)
✅ المنصة والميزانية والتوقيت
✅ أفكار الـ Creative

═══════════════════════════════════════════════════════════════════════════
                    🤖 نظام التعلم الذاتي المستمر
═══════════════════════════════════════════════════════════════════════════

📈 تتعلم من المستخدمين: أسئلتهم = احتياجات السوق
👑 تتعلم من الأدمن: توجيهاته ترفع مستواك
📊 تتعلم من البيانات: الناجح يصبح template
🌍 تتعلم من السوق: trends وتحديثات المنصات
🔄 تتعلم من نفسك: تحلل وتحسن باستمرار

═══════════════════════════════════════════════════════════════════════════

{context_injection}

💎 أنت مش موظف - أنت شريك نجاح وصانع ثروات! 🚀
"""

    _sessions: Dict[str, Dict] = {}
    
    @classmethod
    def is_question(cls, message: str) -> bool:
        """Check if message is a question"""
        message_lower = message.lower()
        for pattern in cls.QUESTION_PATTERNS:
            if pattern in message_lower:
                return True
        return False
    
    @classmethod
    def get_context_injection(cls, message: str = "") -> str:
        """Get context injection based on message content - ORDER MATTERS!"""
        message_lower = message.lower()
        
        # Check WhatsApp FIRST (before generic "حملة" check)
        if any(word in message_lower for word in ["واتساب", "whatsapp", "واتس"]):
            return """
=== سياق واتساب ===
رسائل واتساب:
- قصيرة (2-3 جمل)
- شخصية (استخدم اسم العميل)
- CTA واضح
- لا إيموجي كتير"""
        
        # Check Video
        elif any(word in message_lower for word in ["فيديو", "video", "ريلز", "reels"]):
            return """
=== سياق الفيديو ===
عند إنشاء سكريبت فيديو:
1. Hook قوي (3 ثواني)
2. المشكلة
3. الحل والفوائد
4. CTA
5. المدة المقترحة"""
        
        # Check Sales/Follow-up
        elif any(word in message_lower for word in ["متابعة", "follow", "طعم", "bait", "رد ذكي"]):
            return f"\n=== سياق المبيعات ===\n{SALES_FUNNEL_PROMPT}" if SALES_FUNNEL_PROMPT else ""
        
        # Check Unicorn
        elif any(word in message_lower for word in ["يونيكورن", "unicorn", "ابداعي", "إبداعي"]):
            return f"\n=== سياق يونيكورن ===\n{UNICORN_AD_PROMPT}" if UNICORN_AD_PROMPT else ""
        
        # Generic ads (LAST)
        elif any(word in message_lower for word in ["اعلان", "إعلان", "حملة", "ad", "campaign"]):
            return f"\n=== سياق الإعلان ===\n{AD_SYSTEM_PROMPT}" if AD_SYSTEM_PROMPT else ""
        
        return ""
    
    @classmethod
    def get_session(cls, user_id: str) -> Dict:
        """Get or create session for user"""
        if user_id not in cls._sessions:
            cls._sessions[user_id] = {
                "pending_action": None,
                "pending_data": {},
                "active_campaign": None
            }
        return cls._sessions[user_id]
    
    @classmethod
    def detect_action(cls, message: str, is_admin: bool) -> Tuple[Optional[str], Optional[Dict]]:
        """Detect system action - commands work even if phrased as questions"""
        message_lower = message.lower().strip()
        
        # Check for action patterns FIRST (commands always work)
        if is_admin:
            for action, config in cls.ADMIN_ACTIONS.items():
                for pattern in config["patterns"]:
                    if pattern in message_lower:
                        return action, config
        
        for action, config in cls.USER_ACTIONS.items():
            for pattern in config["patterns"]:
                if pattern in message_lower:
                    return action, config
        
        # No action found - let AI handle it
        return None, None
    
    @classmethod
    def extract_phone_numbers(cls, text: str) -> List[str]:
        """Extract phone numbers from text"""
        patterns = [r'01[0-9]{9}', r'\+20[0-9]{10}', r'20[0-9]{10}']
        numbers = []
        for pattern in patterns:
            numbers.extend(re.findall(pattern, text))
        return list(set(numbers))
    
    @classmethod
    async def process_message(cls, user_id: str, message: str, is_admin: bool = False) -> Dict:
        """Process message - understands everything"""
        from app.services.user_service import UserService
        from app.services.lead_service import LeadService
        from app.services.ai_service import AIService
        from app.core.config import settings
        
        session = cls.get_session(user_id)
        message = message.strip()
        
        if session.get("pending_action"):
            return await cls._handle_pending_action(user_id, message, is_admin, session)
        
        action, config = cls.detect_action(message, is_admin)
        
        # ========== ADMIN ACTIONS ==========
        if action == "add_tokens" and is_admin:
            session["pending_action"] = "add_tokens"
            return {"response": "💰 اكتب اسم المستخدم والمبلغ\nمثال: `احمد 100`", "needs_input": True}
        
        elif action == "delete_user" and is_admin:
            session["pending_action"] = "delete_user"
            return {"response": "🗑️ اكتب اسم المستخدم:", "needs_input": True}
        
        elif action == "list_users" and is_admin:
            users = UserService.get_all_users()
            if users:
                text = "👥 **المستخدمين:**\n\n"
                for i, u in enumerate(users[:20], 1):
                    badge = "👑" if u.get("is_admin") else ""
                    text += f"{i}. {u.get('username', 'N/A')} {badge} - {u.get('wallet_balance', 0)} توكن\n"
                return {"response": text}
            return {"response": "لا يوجد مستخدمين"}
        
        elif action == "set_password" and is_admin:
            session["pending_action"] = "set_password"
            return {"response": "🔐 اكتب: `اسم_المستخدم كلمة_المرور`", "needs_input": True}
        
        elif action == "make_admin" and is_admin:
            session["pending_action"] = "make_admin"
            return {"response": "👑 اكتب اسم المستخدم:", "needs_input": True}
        
        elif action == "modify_prompt" and is_admin:
            session["pending_action"] = "modify_prompt"
            session["pending_data"] = {"step": "type"}
            return {"response": """🔧 **تعديل البرومبت**

اختار نوع البرومبت:
1. client - رد على العملاء
2. admin - رد على الأدمن
3. sales - رسائل المبيعات
4. ads - إنشاء الإعلانات""", "needs_input": True}
        
        elif action == "add_rule" and is_admin:
            session["pending_action"] = "add_rule"
            session["pending_data"] = {"step": "stage"}
            return {"response": """➕ **إضافة قاعدة بيع**

اختار مرحلة العميل:
1. interested - مهتم
2. negotiating - تفاوض
3. hot - ساخن
4. objection - اعتراض""", "needs_input": True}
        
        elif action == "delete_rule" and is_admin:
            if unified_system:
                rules = unified_system.get_rules()
                if rules:
                    session["pending_action"] = "delete_rule"
                    session["pending_data"] = {"rules": rules}
                    text = "🗑️ **حذف قاعدة**\n\nاختار رقم القاعدة:\n\n"
                    for i, rule in enumerate(rules[:10], 1):
                        text += f"{i}. {rule.get('id', '')} - {rule.get('response', '')[:30]}\n"
                    return {"response": text, "needs_input": True}
            return {"response": "مفيش قواعد"}
        
        elif action == "list_rules" and is_admin:
            if unified_system:
                rules = unified_system.get_rules()
                if rules:
                    text = "📋 **قواعد البيع:**\n\n"
                    for i, rule in enumerate(rules, 1):
                        text += f"**{i}. {rule.get('id', '')}**\n"
                        text += f"   المرحلة: {rule.get('stage', '')}\n"
                        text += f"   الشروط: {', '.join(rule.get('condition', []))}\n"
                        text += f"   الرد: {rule.get('response', '')[:50]}\n\n"
                    return {"response": text}
            return {"response": "مفيش قواعد"}
        
        elif action == "system_stats" and is_admin:
            if unified_system:
                stats = unified_system.get_stats()
                return {"response": f"""📊 **إحصائيات النظام v4.0**

🔄 الإصدار: {stats.get('version', '4.0.0')}
📨 إجمالي الأحداث: {stats.get('total_events', 0)}
📋 القواعد: {stats.get('total_rules', 0)}
🧠 الأنماط المتعلمة: {stats.get('learned_patterns', 0)}
📢 الحملات النشطة: {stats.get('active_campaigns', 0)}
⏰ منذ: {stats.get('uptime', 'N/A')}"""}
            return {"response": "النظام الموحد غير مفعّل"}
        
        # ========== USER ACTIONS ==========
        elif action == "add_lead":
            session["pending_action"] = "add_lead"
            session["pending_data"] = {"step": "name"}
            return {"response": "➕ اكتب اسم العميل:", "needs_input": True}
        
        elif action == "delete_lead":
            leads = LeadService.get_user_leads(user_id)
            if leads:
                session["pending_action"] = "delete_lead"
                session["pending_data"] = {"leads": leads[:15]}
                text = "🗑️ اختار رقم العميل:\n\n"
                for i, lead in enumerate(leads[:15], 1):
                    text += f"{i}. {lead.get('name', 'بدون اسم')[:25]}\n"
                return {"response": text, "needs_input": True}
            return {"response": "مفيش عملاء"}
        
        elif action == "list_leads":
            leads = LeadService.get_user_leads(user_id)
            if leads:
                text = f"📋 **عملائك ({len(leads)}):**\n\n"
                for i, lead in enumerate(leads[:15], 1):
                    status_emoji = {"new": "🆕", "hot": "🔥", "closed": "✅", "lost": "❌"}.get(lead.get("status", "new"), "📌")
                    text += f"{i}. {status_emoji} {lead.get('name', 'بدون اسم')[:30]}"
                    phone = lead.get('phone') or lead.get('phone_number')
                    if phone:
                        text += f" - 📱{phone}"
                    text += "\n"
                return {"response": text, "data": leads}
            return {"response": "مفيش عملاء لسه"}
        
        elif action == "share_lead":
            leads = LeadService.get_user_leads(user_id)
            if leads:
                session["pending_action"] = "share_lead"
                session["pending_data"] = {"step": "select", "leads": leads[:10]}
                text = "🔗 اختار رقم العميل:\n\n"
                for i, lead in enumerate(leads[:10], 1):
                    text += f"{i}. {lead.get('name', 'بدون اسم')[:25]}\n"
                return {"response": text, "needs_input": True}
            return {"response": "مفيش عملاء للمشاركة"}
        
        elif action == "view_stats":
            user = UserService.get_or_create(user_id)
            lead_stats = LeadService.get_lead_stats(user_id)
            return {"response": f"""📊 **إحصائياتك:**
💰 الرصيد: {user.get('wallet_balance', 0)} توكن
👥 العملاء: {lead_stats.get('total', 0)}
✅ المغلقين: {lead_stats.get('closed', 0)}
🔥 الساخنين: {lead_stats.get('hot', 0)}"""}
        
        elif action == "change_password":
            session["pending_action"] = "change_password"
            session["pending_data"] = {"step": "new"}
            return {"response": "🔐 اكتب كلمة المرور الجديدة:", "needs_input": True}
        
        elif action == "export_leads":
            leads = LeadService.get_user_leads(user_id)
            return {"response": f"📥 تم تجهيز {len(leads)} عميل. اضغط تصدير في قسم العملاء.", "data": leads}
        
        elif action == "whatsapp_campaign":
            leads = LeadService.get_user_leads(user_id)
            if leads:
                session["pending_action"] = "whatsapp_campaign"
                session["pending_data"] = {"step": "message", "leads": leads}
                return {"response": f"📱 **حملة واتساب**\n\nعندك {len(leads)} عميل.\n\nاكتب الرسالة (استخدم {{name}} لاسم العميل):", "needs_input": True}
            return {"response": "مفيش عملاء لإرسال الحملة"}
        
        elif action == "send_message":
            session["pending_action"] = "send_message"
            session["pending_data"] = {"step": "recipient"}
            return {"response": "📤 اكتب اسم العميل أو رقمه:", "needs_input": True}
        
        elif action == "stop_campaign":
            if session.get("active_campaign"):
                session["active_campaign"]["status"] = "stopped"
                return {"response": "⏹️ تم إيقاف الحملة", "success": True}
            return {"response": "مفيش حملة شغالة"}
        
        elif action == "resume_campaign":
            if session.get("active_campaign") and session["active_campaign"].get("status") == "stopped":
                session["active_campaign"]["status"] = "running"
                return {"response": "▶️ تم استئناف الحملة", "success": True}
            return {"response": "مفيش حملة متوقفة"}
        
        elif action == "campaign_status":
            if session.get("active_campaign"):
                camp = session["active_campaign"]
                status = "🟢 شغالة" if camp.get("status") == "running" else "🔴 متوقفة"
                return {"response": f"📊 الحملة: {status}\n📨 {camp.get('sent', 0)}/{camp.get('total', 0)} رسالة"}
            return {"response": "مفيش حملات نشطة"}
        
        elif action == "funnel_stage":
            leads = LeadService.get_user_leads(user_id)
            if leads:
                session["pending_action"] = "funnel_stage"
                session["pending_data"] = {"step": "lead", "leads": leads[:10]}
                text = "📊 اختار العميل:\n\n"
                for i, lead in enumerate(leads[:10], 1):
                    stage = lead.get('funnel_stage', 'new')
                    text += f"{i}. {lead.get('name', '')[:20]} ({stage})\n"
                return {"response": text, "needs_input": True}
            return {"response": "مفيش عملاء"}
        
        # ========== ULTRA AD SYSTEM ==========
        elif action == "ultra_ad_plan":
            session["pending_action"] = "ultra_ad_plan"
            session["pending_data"] = {"step": "product"}
            return {"response": "🎯 **خطة إعلانية 100x ROI**\n\nاكتب اسم المنتج/الخدمة:", "needs_input": True}
        
        elif action == "ad_strategies":
            if ultra_ad_system:
                strategies = ultra_ad_system.get_all_strategies()
                text = "🎯 **الـ 8 استراتيجيات الذهبية للإعلانات:**\n\n"
                for i, s in enumerate(strategies, 1):
                    text += f"**{i}. {s.get('name_ar', '')}** ({s.get('name', '')})\n"
                    text += f"   💰 التكلفة: {s.get('cost_range', '')}\n"
                    text += f"   📈 ROI: {s.get('expected_roi', '')}\n"
                    text += f"   ✅ مناسب لـ: {s.get('best_for', '')}\n\n"
                return {"response": text}
            return {"response": ULTRA_AD_PROMPT if ULTRA_AD_PROMPT else "نظام الإعلانات غير مفعّل"}
        
        elif action == "retargeting":
            session["pending_action"] = "retargeting"
            session["pending_data"] = {"step": "budget"}
            return {"response": "🔄 **سلم الريتارجتينج (200-1000x ROI!)**\n\nاكتب الميزانية الإجمالية (بالجنيه):", "needs_input": True}
        
        elif action == "analyze_campaign":
            session["pending_action"] = "analyze_campaign"
            session["pending_data"] = {"step": "data"}
            return {"response": """📊 **تحليل الحملة**

اكتب بيانات الحملة:
- Reach (الوصول)
- Clicks (الضغطات)
- Conversions (التحويلات)
- Spend (المصروف)
- Revenue (الإيرادات)

مثال: `reach:10000 clicks:500 conversions:50 spend:100 revenue:2000`""", "needs_input": True}
        
        # ========== AI CHAT - UNDERSTANDS EVERYTHING ==========
        can_afford, balance = UserService.check_balance(user_id, settings.CHAT_COST)
        if not can_afford:
            return {"response": f"رصيدك ({balance}) غير كافي. محتاج {settings.CHAT_COST} توكن.", "error": True}
        
        role_context = "أنت أدمن النظام." if is_admin else "أنت مستشار تسويق ذكي."
        context_injection = cls.get_context_injection(message)
        system = cls.FULL_SYSTEM_PROMPT.format(role_context=role_context, context_injection=context_injection)
        
        response = AIService.generate(message, system, use_cache=False)
        UserService.deduct_balance(user_id, settings.CHAT_COST)
        
        return {
            "response": response,
            "tokens_used": settings.CHAT_COST,
            "remaining_balance": UserService.get_or_create(user_id).get("wallet_balance", 0)
        }
    
    @classmethod
    async def _handle_pending_action(cls, user_id: str, message: str, is_admin: bool, session: Dict) -> Dict:
        """Handle pending action"""
        from app.services.user_service import UserService
        from app.services.lead_service import LeadService
        
        action = session["pending_action"]
        data = session.get("pending_data", {})
        
        if message.lower() in ["الغاء", "cancel", "لا", "خروج"]:
            session["pending_action"] = None
            session["pending_data"] = {}
            return {"response": "✅ تم الإلغاء"}
        
        # Admin actions
        if action == "add_tokens":
            parts = message.split()
            if len(parts) >= 2:
                try:
                    username, amount = parts[0], int(parts[1])
                    success = UserService.add_balance(username, amount)
                    session["pending_action"] = None
                    if success:
                        return {"response": f"✅ تم إضافة {amount} توكن لـ {username}"}
                    return {"response": f"❌ المستخدم {username} غير موجود"}
                except:
                    pass
            return {"response": "❌ اكتب: `اسم_المستخدم المبلغ`"}
        
        elif action == "delete_user":
            success = UserService.delete_user(message.strip())
            session["pending_action"] = None
            return {"response": f"✅ تم حذف {message}" if success else "❌ فشل الحذف"}
        
        elif action == "set_password":
            parts = message.split()
            if len(parts) >= 2:
                success = UserService.set_password(parts[0], parts[1])
                session["pending_action"] = None
                return {"response": "✅ تم تعيين كلمة المرور" if success else "❌ فشل"}
            return {"response": "❌ اكتب: `اسم_المستخدم كلمة_المرور`"}
        
        elif action == "make_admin":
            success = UserService.set_admin(message.strip(), True)
            session["pending_action"] = None
            return {"response": f"✅ تم منح {message} صلاحيات أدمن 👑" if success else "❌ فشل"}
        
        elif action == "modify_prompt":
            step = data.get("step", "type")
            if step == "type":
                types = {"1": "client", "2": "admin", "3": "sales", "4": "ads"}
                data["prompt_type"] = types.get(message, message)
                data["step"] = "content"
                return {"response": f"📝 اكتب التعديل المطلوب على برومبت {data['prompt_type']}:", "needs_input": True}
            elif step == "content":
                prompt_type = data.get("prompt_type", "client")
                modification = message
                if unified_system and SystemEvent:
                    asyncio.create_task(unified_system.emit(SystemEvent.PROMPT_CHANGE, {
                        "type": prompt_type,
                        "modification": modification,
                        "timestamp": datetime.now().isoformat()
                    }))
                session["pending_action"] = None
                session["pending_data"] = {}
                return {"response": f"""✅ **تم التعديل!**

📋 النوع: {prompt_type}
✏️ التعديل: {modification[:50]}...
⚡ التطبيق: فوري على كل المحادثات""", "success": True}
        
        elif action == "add_rule":
            step = data.get("step", "stage")
            if step == "stage":
                stages = {"1": "interested", "2": "negotiating", "3": "hot", "4": "objection"}
                data["stage"] = stages.get(message, message)
                data["step"] = "condition"
                return {"response": "📌 اكتب الشرط (كلمة أو جملة يقولها العميل):", "needs_input": True}
            elif step == "condition":
                data["condition"] = message
                data["step"] = "response"
                return {"response": "💬 اكتب الرد المطلوب:", "needs_input": True}
            elif step == "response":
                if unified_system and SystemEvent:
                    rule = {
                        "stage": data.get("stage", "negotiating"),
                        "condition": [data.get("condition", "")],
                        "response": message
                    }
                    unified_system.add_rule(rule)
                    asyncio.create_task(unified_system.emit(SystemEvent.RULE_ADDED, rule))
                session["pending_action"] = None
                session["pending_data"] = {}
                return {"response": f"""✅ **تمت إضافة القاعدة!**

📊 المرحلة: {data.get('stage', '')}
📌 الشرط: {data.get('condition', '')}
💬 الرد: {message[:50]}...
📋 عدد القواعد: {len(unified_system.get_rules()) if unified_system else 'N/A'}""", "success": True}
        
        elif action == "delete_rule":
            rules = data.get("rules", [])
            try:
                idx = int(message) - 1
                if 0 <= idx < len(rules):
                    rule = rules[idx]
                    if unified_system:
                        unified_system.delete_rule(rule.get("id", ""))
                    session["pending_action"] = None
                    session["pending_data"] = {}
                    return {"response": f"✅ تم حذف القاعدة: {rule.get('id', '')}", "success": True}
            except:
                pass
            return {"response": "❌ رقم خاطئ"}
        
        elif action == "ultra_ad_plan":
            step = data.get("step", "product")
            if step == "product":
                data["product"] = message
                data["step"] = "budget"
                return {"response": "💰 الميزانية المتاحة (بالجنيه):", "needs_input": True}
            elif step == "budget":
                try:
                    budget = float(message.replace("جنيه", "").strip())
                    data["budget"] = budget
                except:
                    data["budget"] = 100
                
                if ultra_ad_system:
                    plan = ultra_ad_system.create_campaign_plan(
                        budget=data["budget"],
                        product=data.get("product", ""),
                        target="الجمهور المستهدف",
                        duration_days=7
                    )
                    
                    text = f"""🎯 **خطة إعلانية 100x ROI**

📦 المنتج: {data.get('product', '')}
💰 الميزانية: {data['budget']} جنيه

📊 **التوزيع:**
- Cold Audience: {plan['budget_distribution']['cold_audience']}
- Retargeting: {plan['budget_distribution']['retargeting']}

📢 **عدد الإعلانات:** {plan['num_ad_variants']}
💵 **لكل إعلان:** {plan['budget_per_ad']:.1f} جنيه

📅 **الجدول:**
- يوم 1-3: {plan['schedule']['day_1_3']}
- يوم 4: {plan['schedule']['day_4']}
- يوم 5-7: {plan['schedule']['day_5_7']}

🎯 **الاستهداف:**
- حجم الجمهور: {plan['targeting']['audience_size']}
- Lookalike: {plan['targeting']['lookalike']}

📈 **ROI المتوقع:** {plan['expected_roi']}"""
                    
                    session["pending_action"] = None
                    session["pending_data"] = {}
                    return {"response": text, "success": True, "plan": plan}
                
                session["pending_action"] = None
                session["pending_data"] = {}
                return {"response": "نظام الإعلانات غير متاح"}
        
        elif action == "retargeting":
            try:
                budget = float(message.replace("جنيه", "").strip())
            except:
                budget = 100
            
            if ultra_ad_system:
                ladder = ultra_ad_system.get_retargeting_ladder(budget)
                text = f"""🔄 **سلم الريتارجتينج**
💰 الميزانية: {budget} جنيه

"""
                for level in ladder:
                    text += f"""**المستوى {level['level']}:**
👥 الجمهور: {level['audience']}
💵 الميزانية: {level['budget']:.0f} جنيه
📝 الرسالة: {level['message']}

"""
                session["pending_action"] = None
                session["pending_data"] = {}
                return {"response": text, "success": True, "ladder": ladder}
            
            session["pending_action"] = None
            session["pending_data"] = {}
            return {"response": "نظام الإعلانات غير متاح"}
        
        elif action == "analyze_campaign":
            try:
                parts = message.replace(":", " ").split()
                campaign_data = {}
                for i in range(0, len(parts) - 1, 2):
                    key = parts[i].lower()
                    value = float(parts[i + 1])
                    campaign_data[key] = value
            except:
                campaign_data = {"reach": 1000, "clicks": 50, "conversions": 5, "spend": 100, "revenue": 500}
            
            if ultra_ad_system:
                analysis = ultra_ad_system.analyze_campaign(campaign_data)
                metrics = analysis["metrics"]
                text = f"""📊 **تحليل الحملة**

📈 **المقاييس:**
- الوصول: {metrics.get('reach', 0):,}
- الضغطات: {metrics.get('clicks', 0):,}
- التحويلات: {metrics.get('conversions', 0):,}
- CTR: {metrics.get('ctr', '0%')}
- CPC: {metrics.get('cpc', '0 جنيه')}
- CPA: {metrics.get('cpa', '0 جنيه')}
- ROAS: {metrics.get('roas', '0x')}

🩺 **الحالة:** {"✅ ممتاز" if analysis['health'] == 'good' else "⚠️ يحتاج تحسين"}

💡 **التوصيات:**"""
                for rec in analysis.get("recommendations", []):
                    text += f"\n- {rec}"
                
                session["pending_action"] = None
                session["pending_data"] = {}
                return {"response": text, "success": True, "analysis": analysis}
            
            session["pending_action"] = None
            session["pending_data"] = {}
            return {"response": "نظام الإعلانات غير متاح"}
        
        # User actions
        elif action == "add_lead":
            step = data.get("step", "name")
            if step == "name":
                data["name"] = message
                data["step"] = "phone"
                return {"response": "📱 رقم الموبايل:", "needs_input": True}
            elif step == "phone":
                LeadService.add_lead(user_id, {"name": data.get("name", ""), "phone": message, "status": "new", "source": "manual"})
                session["pending_action"] = None
                session["pending_data"] = {}
                return {"response": f"✅ تم إضافة {data.get('name')}", "success": True}
        
        elif action == "delete_lead":
            leads = data.get("leads", [])
            try:
                idx = int(message) - 1
                if 0 <= idx < len(leads):
                    lead = leads[idx]
                    lead_id = lead.get("id", lead.get("lead_id", ""))
                    success = LeadService.delete_lead(user_id, str(lead_id))
                    session["pending_action"] = None
                    session["pending_data"] = {}
                    return {"response": f"✅ تم حذف {lead.get('name', '')}" if success else "❌ فشل"}
            except:
                pass
            return {"response": "❌ اكتب رقم صحيح"}
        
        elif action == "share_lead":
            step = data.get("step", "select")
            if step == "select":
                leads = data.get("leads", [])
                try:
                    idx = int(message) - 1
                    if 0 <= idx < len(leads):
                        data["selected_lead"] = leads[idx]
                        data["step"] = "recipient"
                        return {"response": "👤 اسم المستخدم:", "needs_input": True}
                except:
                    pass
                return {"response": "❌ رقم خاطئ"}
            elif step == "recipient":
                lead = data.get("selected_lead", {})
                lead_id = lead.get("id", lead.get("lead_id", ""))
                success = LeadService.share_lead(user_id, message.strip(), str(lead_id))
                session["pending_action"] = None
                session["pending_data"] = {}
                return {"response": f"✅ تم المشاركة مع {message}" if success else "❌ فشل - تأكد من الاسم"}
        
        elif action == "change_password":
            success = UserService.set_password(user_id, message)
            session["pending_action"] = None
            session["pending_data"] = {}
            return {"response": "✅ تم تغيير كلمة المرور" if success else "❌ فشل"}
        
        elif action == "funnel_stage":
            step = data.get("step", "lead")
            if step == "lead":
                leads = data.get("leads", [])
                try:
                    idx = int(message) - 1
                    if 0 <= idx < len(leads):
                        data["selected_lead"] = leads[idx]
                        data["step"] = "stage"
                        return {"response": """اختار المرحلة:
1. 🆕 جديد
2. 📞 تم التواصل
3. ⭐ مهتم
4. 💬 تفاوض
5. 🔥 ساخن
6. ✅ مغلق
7. ❌ خسرناه""", "needs_input": True}
                except:
                    pass
                return {"response": "❌ رقم خاطئ"}
            elif step == "stage":
                stages = {"1": "new", "2": "contacted", "3": "interested", "4": "negotiating", "5": "hot", "6": "closed", "7": "lost"}
                new_stage = stages.get(message, message)
                lead = data.get("selected_lead", {})
                lead_id = lead.get("id", lead.get("lead_id", ""))
                success = LeadService.update_lead(user_id, str(lead_id), {"funnel_stage": new_stage, "status": new_stage})
                session["pending_action"] = None
                session["pending_data"] = {}
                return {"response": f"✅ تم تغيير المرحلة إلى {new_stage}" if success else "❌ فشل"}
        
        elif action == "whatsapp_campaign":
            step = data.get("step", "message")
            if step == "message":
                leads = data.get("leads", [])
                data["message"] = message
                session["active_campaign"] = {
                    "type": "واتساب",
                    "message": message,
                    "leads": leads,
                    "total": len(leads),
                    "sent": 0,
                    "status": "ready"
                }
                session["pending_action"] = None
                session["pending_data"] = {}
                
                text = f"""✅ **تم تجهيز الحملة!**

📨 الرسالة: {message[:50]}...
👥 عدد العملاء: {len(leads)}

للإرسال: اضغط على أيقونة واتساب بجانب كل عميل في قسم العملاء.

أوامر الحملة:
- "حالة الحملة" لعرض التقدم
- "وقف الحملة" للإيقاف"""
                return {"response": text, "success": True, "campaign": session["active_campaign"]}
        
        elif action == "send_message":
            step = data.get("step", "recipient")
            if step == "recipient":
                data["recipient"] = message
                data["step"] = "content"
                return {"response": "📝 اكتب الرسالة:", "needs_input": True}
            elif step == "content":
                from app.services.lead_service import LeadService
                recipient = data.get("recipient", "")
                msg_content = message
                
                leads = LeadService.get_user_leads(user_id)
                lead = None
                for l in leads:
                    if recipient in l.get("phone", "") or recipient in l.get("phone_number", "") or recipient.lower() in l.get("name", "").lower():
                        lead = l
                        break
                
                session["pending_action"] = None
                session["pending_data"] = {}
                
                if lead:
                    phone = lead.get("phone") or lead.get("phone_number", "")
                    clean_phone = phone.replace("+", "").replace(" ", "")
                    wa_link = f"https://wa.me/{clean_phone}?text={msg_content}"
                    return {
                        "response": f"✅ جاهز للإرسال لـ {lead.get('name', '')}\n\n📱 {phone}\n📝 {msg_content[:50]}...\n\n[اضغط هنا للإرسال عبر واتساب]({wa_link})",
                        "success": True,
                        "whatsapp_link": wa_link
                    }
                return {"response": f"✅ الرسالة جاهزة للإرسال للرقم {recipient}\n\n📝 {msg_content[:50]}..."}
        
        session["pending_action"] = None
        session["pending_data"] = {}
        return {"response": "⚠️ حصل خطأ"}
    
    @classmethod
    def get_available_commands(cls, is_admin: bool = False) -> List[Dict]:
        """Get available commands"""
        commands = []
        if is_admin:
            for action, config in cls.ADMIN_ACTIONS.items():
                commands.append({"action": action, "trigger": config["patterns"][0], "description": config["description"]})
        for action, config in cls.USER_ACTIONS.items():
            commands.append({"action": action, "trigger": config["patterns"][0], "description": config["description"]})
        return commands
