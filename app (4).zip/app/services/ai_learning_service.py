"""
AI Self-Learning Service - Learns from interactions and improves over time
"""
import json
import os
from datetime import datetime
from typing import Dict, List, Optional

LEARNINGS_FILE = "ai_learnings.json"

class AILearningService:
    """Self-learning AI system that improves from every interaction"""
    
    _learnings: Dict = {
        "successful_ads": [],
        "successful_replies": [],
        "user_preferences": {},
        "common_questions": {},
        "admin_teachings": [],
        "conversion_patterns": [],
        "market_insights": [],
        "last_updated": None
    }
    
    @classmethod
    def load_learnings(cls):
        """Load learnings from file"""
        try:
            if os.path.exists(LEARNINGS_FILE):
                with open(LEARNINGS_FILE, "r", encoding="utf-8") as f:
                    cls._learnings = json.load(f)
        except Exception as e:
            print(f"Load learnings error: {e}")
    
    @classmethod
    def save_learnings(cls):
        """Save learnings to file"""
        try:
            cls._learnings["last_updated"] = datetime.now().isoformat()
            with open(LEARNINGS_FILE, "w", encoding="utf-8") as f:
                json.dump(cls._learnings, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Save learnings error: {e}")
    
    @classmethod
    def learn_from_ad(cls, ad_content: str, product: str, audience: str, success_score: int = 0):
        """Learn from a successful ad"""
        learning = {
            "content": ad_content[:500],
            "product": product,
            "audience": audience,
            "score": success_score,
            "date": datetime.now().isoformat()
        }
        cls._learnings["successful_ads"].append(learning)
        if len(cls._learnings["successful_ads"]) > 100:
            cls._learnings["successful_ads"] = cls._learnings["successful_ads"][-100:]
        cls.save_learnings()
    
    @classmethod
    def learn_from_reply(cls, context: str, reply: str, was_successful: bool):
        """Learn from a successful sales reply"""
        if was_successful:
            learning = {
                "context": context[:200],
                "reply": reply[:300],
                "date": datetime.now().isoformat()
            }
            cls._learnings["successful_replies"].append(learning)
            if len(cls._learnings["successful_replies"]) > 50:
                cls._learnings["successful_replies"] = cls._learnings["successful_replies"][-50:]
            cls.save_learnings()
    
    @classmethod
    def learn_user_preference(cls, user_id: str, preference_type: str, value: str):
        """Learn user preferences"""
        if user_id not in cls._learnings["user_preferences"]:
            cls._learnings["user_preferences"][user_id] = {}
        cls._learnings["user_preferences"][user_id][preference_type] = value
        cls.save_learnings()
    
    @classmethod
    def learn_common_question(cls, question: str, best_answer: str):
        """Learn from common questions"""
        q_key = question[:50].lower()
        cls._learnings["common_questions"][q_key] = {
            "question": question,
            "answer": best_answer,
            "count": cls._learnings["common_questions"].get(q_key, {}).get("count", 0) + 1
        }
        cls.save_learnings()
    
    @classmethod
    def add_admin_teaching(cls, teaching: str, category: str = "general"):
        """Add admin teaching"""
        cls._learnings["admin_teachings"].append({
            "teaching": teaching,
            "category": category,
            "date": datetime.now().isoformat()
        })
        cls.save_learnings()
    
    @classmethod
    def learn_conversion_pattern(cls, lead_source: str, messages_count: int, converted: bool):
        """Learn from conversion patterns"""
        cls._learnings["conversion_patterns"].append({
            "source": lead_source,
            "messages": messages_count,
            "converted": converted,
            "date": datetime.now().isoformat()
        })
        if len(cls._learnings["conversion_patterns"]) > 200:
            cls._learnings["conversion_patterns"] = cls._learnings["conversion_patterns"][-200:]
        cls.save_learnings()
    
    @classmethod
    def add_market_insight(cls, insight: str, source: str = "observation"):
        """Add market insight"""
        cls._learnings["market_insights"].append({
            "insight": insight,
            "source": source,
            "date": datetime.now().isoformat()
        })
        if len(cls._learnings["market_insights"]) > 50:
            cls._learnings["market_insights"] = cls._learnings["market_insights"][-50:]
        cls.save_learnings()
    
    @classmethod
    def learn_from_conversation(cls, conversation: str, source: str = "whatsapp", was_successful: bool = True):
        """Learn from imported WhatsApp/Messenger conversations"""
        lines = conversation.strip().split('\n')
        patterns_found = []
        
        for i, line in enumerate(lines):
            line = line.strip()
            if not line:
                continue
            
            is_customer = any(x in line.lower() for x in ['العميل:', 'client:', 'customer:', '👤'])
            is_seller = any(x in line.lower() for x in ['أنا:', 'me:', 'seller:', '🧑‍💼', 'انت:'])
            
            if is_seller and i > 0:
                context = lines[i-1] if i > 0 else ""
                reply = line
                patterns_found.append({
                    "context": context[:200],
                    "reply": reply[:300],
                    "source": source,
                    "successful": was_successful
                })
        
        if not patterns_found and lines:
            for i in range(0, len(lines)-1, 2):
                if i+1 < len(lines):
                    patterns_found.append({
                        "context": lines[i][:200],
                        "reply": lines[i+1][:300],
                        "source": source,
                        "successful": was_successful
                    })
        
        for pattern in patterns_found[:20]:
            if was_successful:
                cls._learnings["successful_replies"].append({
                    "context": pattern["context"],
                    "reply": pattern["reply"],
                    "source": source,
                    "date": datetime.now().isoformat()
                })
        
        if len(cls._learnings["successful_replies"]) > 100:
            cls._learnings["successful_replies"] = cls._learnings["successful_replies"][-100:]
        
        cls.save_learnings()
        
        return {
            "success": True,
            "patterns_learned": len(patterns_found),
            "message": f"تم التعلم من {len(patterns_found)} رد ناجح من {source} ✓"
        }
    
    @classmethod
    def get_successful_replies_context(cls, customer_message: str) -> str:
        """Get relevant successful replies for a customer message"""
        relevant = []
        keywords = customer_message.lower().split()
        
        for reply_data in cls._learnings.get("successful_replies", [])[-50:]:
            context = reply_data.get("context", "").lower()
            if any(kw in context for kw in keywords if len(kw) > 2):
                relevant.append(reply_data)
        
        if relevant:
            context_parts = ["📚 ردود ناجحة سابقة:"]
            for r in relevant[:3]:
                context_parts.append(f"  العميل: {r['context'][:50]}...")
                context_parts.append(f"  الرد: {r['reply'][:100]}...")
            return "\n".join(context_parts)
        return ""
    
    @classmethod
    def get_learning_context(cls) -> str:
        """Get learning context to inject into AI prompts"""
        context_parts = []
        
        if cls._learnings["admin_teachings"]:
            teachings = cls._learnings["admin_teachings"][-5:]
            context_parts.append("📚 تعليمات الأدمن:")
            for t in teachings:
                context_parts.append(f"  • {t['teaching']}")
        
        if cls._learnings["successful_ads"]:
            context_parts.append("\n🎯 أنماط الإعلانات الناجحة:")
            for ad in cls._learnings["successful_ads"][-3:]:
                context_parts.append(f"  • {ad['product']}: {ad['content'][:100]}...")
        
        if cls._learnings["market_insights"]:
            context_parts.append("\n💡 رؤى السوق:")
            for insight in cls._learnings["market_insights"][-3:]:
                context_parts.append(f"  • {insight['insight']}")
        
        return "\n".join(context_parts) if context_parts else ""
    
    @classmethod
    def get_stats(cls) -> Dict:
        """Get learning statistics"""
        return {
            "successful_ads": len(cls._learnings.get("successful_ads", [])),
            "successful_replies": len(cls._learnings.get("successful_replies", [])),
            "user_preferences": len(cls._learnings.get("user_preferences", {})),
            "common_questions": len(cls._learnings.get("common_questions", {})),
            "admin_teachings": len(cls._learnings.get("admin_teachings", [])),
            "conversion_patterns": len(cls._learnings.get("conversion_patterns", [])),
            "market_insights": len(cls._learnings.get("market_insights", [])),
            "last_updated": cls._learnings.get("last_updated")
        }


AILearningService.load_learnings()
