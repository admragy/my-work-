"""
Messenger Learning Service - يحلل المحادثات ويتعلم الأنماط الناجحة
يراقب شات الماسنجر ويستخرج الردود الفعالة
"""

import os
import json
import asyncio
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import httpx

try:
    from openai import OpenAI
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False


class MessengerLearningService:
    """خدمة التعلم من محادثات الماسنجر"""
    
    def __init__(self):
        self.learned_responses = {}
        self.conversation_patterns = {}
        self.successful_closings = {}
        
        if HAS_OPENAI and os.environ.get("OPENAI_API_KEY"):
            self.openai_client = OpenAI()
        else:
            self.openai_client = None
    
    async def fetch_page_conversations(self, access_token: str, page_id: str) -> List[Dict]:
        """جلب محادثات الصفحة من فيسبوك"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"https://graph.facebook.com/v18.0/{page_id}/conversations",
                    params={
                        "access_token": access_token,
                        "fields": "id,participants,messages{message,from,created_time}",
                        "limit": 50
                    },
                    timeout=30
                )
                
                if response.status_code == 200:
                    data = response.json()
                    return data.get("data", [])
                else:
                    print(f"Error fetching conversations: {response.text}")
                    return []
        except Exception as e:
            print(f"Error in fetch_page_conversations: {e}")
            return []
    
    async def analyze_conversation(self, conversation: Dict, page_id: str) -> Dict:
        """تحليل محادثة واحدة"""
        analysis = {
            "id": conversation.get("id"),
            "messages_count": 0,
            "response_times": [],
            "customer_messages": [],
            "page_responses": [],
            "outcome": "unknown",
            "sentiment": "neutral"
        }
        
        messages = conversation.get("messages", {}).get("data", [])
        analysis["messages_count"] = len(messages)
        
        prev_time = None
        for msg in reversed(messages):
            from_id = msg.get("from", {}).get("id", "")
            message_text = msg.get("message", "")
            created_time = msg.get("created_time")
            
            if from_id == page_id:
                analysis["page_responses"].append(message_text)
                if prev_time and created_time:
                    try:
                        t1 = datetime.fromisoformat(created_time.replace('Z', '+00:00'))
                        t2 = datetime.fromisoformat(prev_time.replace('Z', '+00:00'))
                        diff = (t1 - t2).total_seconds() / 60
                        if diff > 0:
                            analysis["response_times"].append(diff)
                    except:
                        pass
            else:
                analysis["customer_messages"].append(message_text)
                prev_time = created_time
        
        analysis["outcome"] = self._detect_outcome(analysis["customer_messages"], analysis["page_responses"])
        
        return analysis
    
    def _detect_outcome(self, customer_msgs: List[str], page_msgs: List[str]) -> str:
        """اكتشاف نتيجة المحادثة"""
        all_text = " ".join(customer_msgs + page_msgs).lower()
        
        closing_words = ["شكرا", "تمام", "اوك", "حجزت", "دفعت", "اشتريت", "موافق", "ابعتلي", "هاخد"]
        rejection_words = ["لا شكرا", "مش مهتم", "غالي", "مش عايز", "بعدين"]
        
        for word in closing_words:
            if word in all_text:
                return "closed"
        
        for word in rejection_words:
            if word in all_text:
                return "lost"
        
        return "pending"
    
    async def extract_successful_patterns(self, conversations: List[Dict], page_id: str) -> Dict:
        """استخراج أنماط المحادثات الناجحة"""
        patterns = {
            "opening_messages": [],
            "objection_handlers": [],
            "closing_messages": [],
            "quick_responses": [],
            "conversion_rate": 0
        }
        
        closed = 0
        total = 0
        
        for conv in conversations:
            analysis = await self.analyze_conversation(conv, page_id)
            total += 1
            
            if analysis["outcome"] == "closed":
                closed += 1
                
                if analysis["page_responses"]:
                    patterns["opening_messages"].append(analysis["page_responses"][0])
                    patterns["closing_messages"].append(analysis["page_responses"][-1])
                
                if analysis["response_times"]:
                    avg_time = sum(analysis["response_times"]) / len(analysis["response_times"])
                    if avg_time < 5:
                        patterns["quick_responses"].extend(analysis["page_responses"][:2])
        
        if total > 0:
            patterns["conversion_rate"] = (closed / total) * 100
        
        return patterns
    
    async def learn_from_conversations(self, user_id: str, access_token: str, page_id: str) -> Dict:
        """التعلم الكامل من محادثات المستخدم"""
        result = {
            "success": False,
            "conversations_analyzed": 0,
            "patterns_learned": 0,
            "conversion_rate": 0,
            "insights": {}
        }
        
        try:
            conversations = await self.fetch_page_conversations(access_token, page_id)
            
            if not conversations:
                result["message"] = "لم يتم العثور على محادثات"
                return result
            
            result["conversations_analyzed"] = len(conversations)
            
            patterns = await self.extract_successful_patterns(conversations, page_id)
            result["conversion_rate"] = patterns["conversion_rate"]
            
            self.learned_responses[user_id] = {
                "patterns": patterns,
                "learned_at": datetime.now().isoformat()
            }
            
            result["patterns_learned"] = (
                len(patterns["opening_messages"]) + 
                len(patterns["closing_messages"]) + 
                len(patterns["quick_responses"])
            )
            
            result["insights"] = await self._generate_conversation_insights(patterns)
            
            result["success"] = True
            result["message"] = f"تم تحليل {result['conversations_analyzed']} محادثة - نسبة الإغلاق {result['conversion_rate']:.1f}%"
            
        except Exception as e:
            result["error"] = str(e)
            result["message"] = f"خطأ في التعلم: {str(e)}"
        
        return result
    
    async def _generate_conversation_insights(self, patterns: Dict) -> Dict:
        """توليد رؤى من المحادثات"""
        if not self.openai_client:
            return self._generate_basic_conversation_insights(patterns)
        
        try:
            patterns_text = json.dumps({
                "opening": patterns["opening_messages"][:5],
                "closing": patterns["closing_messages"][:5],
                "conversion_rate": patterns["conversion_rate"]
            }, ensure_ascii=False, indent=2)
            
            response = self.openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {
                        "role": "system",
                        "content": """أنت خبير مبيعات. حلل المحادثات الناجحة واستخرج:
1. أفضل رسائل الترحيب
2. أفضل ردود الإغلاق
3. نصائح لتحسين المحادثات
4. الأخطاء التي يجب تجنبها

رد بـ JSON فقط."""
                    },
                    {
                        "role": "user",
                        "content": f"أنماط المحادثات الناجحة:\n{patterns_text}"
                    }
                ],
                max_tokens=1000
            )
            
            content = response.choices[0].message.content
            try:
                return json.loads(content)
            except:
                return {"raw_insights": content}
                
        except Exception as e:
            print(f"AI conversation insights error: {e}")
            return self._generate_basic_conversation_insights(patterns)
    
    def _generate_basic_conversation_insights(self, patterns: Dict) -> Dict:
        """رؤى أساسية بدون AI"""
        return {
            "best_openings": patterns["opening_messages"][:3],
            "best_closings": patterns["closing_messages"][:3],
            "conversion_rate": patterns["conversion_rate"],
            "quick_response_examples": patterns["quick_responses"][:3]
        }
    
    def get_smart_reply(self, user_id: str, customer_message: str, context: str = "") -> str:
        """الحصول على رد ذكي مبني على التعلم"""
        learned = self.learned_responses.get(user_id, {}).get("patterns", {})
        
        if not learned:
            return self._get_default_reply(customer_message)
        
        msg_lower = customer_message.lower()
        
        greetings = ["مرحبا", "السلام", "ازيك", "هاي", "صباح", "مساء"]
        if any(g in msg_lower for g in greetings):
            if learned.get("opening_messages"):
                return learned["opening_messages"][0]
        
        closing_signals = ["عايز", "هاخد", "ابعتلي", "كام", "السعر"]
        if any(s in msg_lower for s in closing_signals):
            if learned.get("closing_messages"):
                return learned["closing_messages"][0]
        
        return self._get_default_reply(customer_message)
    
    def _get_default_reply(self, message: str) -> str:
        """رد افتراضي"""
        return "أهلاً بيك! إزاي أقدر أساعدك النهارده؟"


messenger_learning_service = MessengerLearningService()
