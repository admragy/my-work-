"""
Lead Distribution Service
Flexible lead distribution: single, bulk, campaign-based
Hunter Pro v4.0
"""
from typing import List, Dict, Any, Optional
from datetime import datetime
import uuid
from app.core.config import settings
import app.core.database as db_module


class DistributionMethod:
    SINGLE = "single"
    BULK = "bulk"
    CAMPAIGN = "campaign"
    ROUND_ROBIN = "round_robin"
    WEIGHTED = "weighted"
    MANUAL = "manual"


class LeadDistributionService:
    """
    Flexible Lead Distribution System
    - Single lead to single user
    - Multiple leads to single user
    - Multiple leads to multiple users
    - Campaign leads to users
    - Round-robin distribution
    - Weighted distribution
    """
    
    distribution_history: List[Dict] = []
    distribution_rules: Dict[str, Dict] = {}
    round_robin_cursor: int = 0
    
    @staticmethod
    def distribute_single(lead_id: str, from_user: str, to_user: str, notes: str = "") -> Dict:
        """Distribute single lead to a user"""
        result = LeadDistributionService._transfer_lead(lead_id, from_user, to_user)
        
        if result["success"]:
            LeadDistributionService._log_distribution(
                method=DistributionMethod.SINGLE,
                leads=[lead_id],
                from_user=from_user,
                to_users=[to_user],
                notes=notes
            )
        
        return result
    
    @staticmethod
    def distribute_bulk(lead_ids: List[str], from_user: str, to_user: str, notes: str = "") -> Dict:
        """Distribute multiple leads to a single user"""
        success_count = 0
        failed_ids = []
        
        for lead_id in lead_ids:
            result = LeadDistributionService._transfer_lead(lead_id, from_user, to_user)
            if result["success"]:
                success_count += 1
            else:
                failed_ids.append(lead_id)
        
        LeadDistributionService._log_distribution(
            method=DistributionMethod.BULK,
            leads=lead_ids,
            from_user=from_user,
            to_users=[to_user],
            notes=notes
        )
        
        return {
            "success": success_count > 0,
            "total": len(lead_ids),
            "distributed": success_count,
            "failed": len(failed_ids),
            "failed_ids": failed_ids,
            "message": f"تم توزيع {success_count} من {len(lead_ids)} عميل ✓"
        }
    
    @staticmethod
    def distribute_to_multiple_users(lead_ids: List[str], from_user: str, to_users: List[str], 
                                      method: str = "round_robin") -> Dict:
        """Distribute leads to multiple users"""
        if method == DistributionMethod.ROUND_ROBIN:
            return LeadDistributionService._distribute_round_robin(lead_ids, from_user, to_users)
        elif method == DistributionMethod.WEIGHTED:
            return LeadDistributionService._distribute_weighted(lead_ids, from_user, to_users)
        else:
            return LeadDistributionService._distribute_equal(lead_ids, from_user, to_users)
    
    @staticmethod
    def distribute_campaign(campaign_id: str, from_user: str, to_users: List[str], 
                           method: str = "round_robin") -> Dict:
        """Distribute all leads from a campaign to users"""
        campaign_leads = LeadDistributionService._get_campaign_leads(campaign_id)
        
        if not campaign_leads:
            return {"success": False, "message": "لا يوجد عملاء في هذه الحملة"}
        
        lead_ids = [l["id"] for l in campaign_leads]
        
        result = LeadDistributionService.distribute_to_multiple_users(
            lead_ids, from_user, to_users, method
        )
        
        result["campaign_id"] = campaign_id
        result["message"] = f"تم توزيع {result.get('distributed', 0)} عميل من الحملة ✓"
        
        return result
    
    @staticmethod
    def _distribute_round_robin(lead_ids: List[str], from_user: str, to_users: List[str]) -> Dict:
        """Distribute leads in round-robin fashion"""
        distribution_map = {user: [] for user in to_users}
        success_count = 0
        
        for i, lead_id in enumerate(lead_ids):
            target_user = to_users[(LeadDistributionService.round_robin_cursor + i) % len(to_users)]
            result = LeadDistributionService._transfer_lead(lead_id, from_user, target_user)
            
            if result["success"]:
                distribution_map[target_user].append(lead_id)
                success_count += 1
        
        LeadDistributionService.round_robin_cursor = (
            LeadDistributionService.round_robin_cursor + len(lead_ids)
        ) % len(to_users)
        
        LeadDistributionService._log_distribution(
            method=DistributionMethod.ROUND_ROBIN,
            leads=lead_ids,
            from_user=from_user,
            to_users=to_users
        )
        
        return {
            "success": success_count > 0,
            "distributed": success_count,
            "total": len(lead_ids),
            "distribution": {user: len(leads) for user, leads in distribution_map.items()},
            "message": f"تم توزيع {success_count} عميل بالتساوي ✓"
        }
    
    @staticmethod
    def _distribute_weighted(lead_ids: List[str], from_user: str, to_users: List[str]) -> Dict:
        """Distribute leads based on weights"""
        weights = LeadDistributionService.distribution_rules.get("weights", {})
        
        if not weights:
            weights = {user: 1 for user in to_users}
        
        total_weight = sum(weights.get(user, 1) for user in to_users)
        distribution_map = {user: [] for user in to_users}
        success_count = 0
        
        lead_idx = 0
        for user in to_users:
            user_weight = weights.get(user, 1)
            share = int(len(lead_ids) * user_weight / total_weight)
            
            for _ in range(share):
                if lead_idx < len(lead_ids):
                    result = LeadDistributionService._transfer_lead(
                        lead_ids[lead_idx], from_user, user
                    )
                    if result["success"]:
                        distribution_map[user].append(lead_ids[lead_idx])
                        success_count += 1
                    lead_idx += 1
        
        while lead_idx < len(lead_ids):
            target_user = to_users[lead_idx % len(to_users)]
            result = LeadDistributionService._transfer_lead(
                lead_ids[lead_idx], from_user, target_user
            )
            if result["success"]:
                distribution_map[target_user].append(lead_ids[lead_idx])
                success_count += 1
            lead_idx += 1
        
        return {
            "success": success_count > 0,
            "distributed": success_count,
            "total": len(lead_ids),
            "distribution": {user: len(leads) for user, leads in distribution_map.items()},
            "message": f"تم توزيع {success_count} عميل حسب الأوزان ✓"
        }
    
    @staticmethod
    def _distribute_equal(lead_ids: List[str], from_user: str, to_users: List[str]) -> Dict:
        """Distribute leads equally among users"""
        return LeadDistributionService._distribute_round_robin(lead_ids, from_user, to_users)
    
    @staticmethod
    def _transfer_lead(lead_id: str, from_user: str, to_user: str) -> Dict:
        """Transfer a single lead from one user to another"""
        try:
            if db_module.DB_TYPE == "replit_pg" and db_module.pg_conn:
                cur = db_module.pg_conn.cursor()
                cur.execute(
                    "UPDATE leads SET user_id = %s, notes = COALESCE(notes, '') || %s WHERE id = %s",
                    (to_user, f"\n[تم النقل من {from_user} في {datetime.now().strftime('%Y-%m-%d %H:%M')}]", lead_id)
                )
                db_module.pg_conn.commit()
                cur.close()
                return {"success": True, "lead_id": lead_id}
            
            elif db_module.DB_TYPE == "supabase" and db_module.supabase:
                db_module.supabase.table("leads").update({
                    "user_id": to_user
                }).eq("id", lead_id).execute()
                return {"success": True, "lead_id": lead_id}
            
            else:
                for lead in db_module.LOCAL_DB.get("leads", []):
                    if lead.get("id") == lead_id:
                        lead["user_id"] = to_user
                        return {"success": True, "lead_id": lead_id}
            
            return {"success": False, "error": "Lead not found"}
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    @staticmethod
    def _get_campaign_leads(campaign_id: str) -> List[Dict]:
        """Get all leads from a campaign"""
        try:
            if db_module.DB_TYPE == "replit_pg" and db_module.pg_conn:
                from psycopg2.extras import RealDictCursor
                cur = db_module.pg_conn.cursor(cursor_factory=RealDictCursor)
                cur.execute(
                    "SELECT * FROM leads WHERE source = %s OR notes LIKE %s",
                    (campaign_id, f"%{campaign_id}%")
                )
                leads = [dict(row) for row in cur.fetchall()]
                cur.close()
                return leads
        except:
            pass
        
        return []
    
    @staticmethod
    def _log_distribution(method: str, leads: List[str], from_user: str, 
                         to_users: List[str], notes: str = ""):
        """Log distribution for history"""
        entry = {
            "id": str(uuid.uuid4()),
            "method": method,
            "lead_count": len(leads),
            "leads": leads[:10],
            "from_user": from_user,
            "to_users": to_users,
            "notes": notes,
            "timestamp": datetime.now().isoformat()
        }
        LeadDistributionService.distribution_history.append(entry)
        
        if len(LeadDistributionService.distribution_history) > 100:
            LeadDistributionService.distribution_history.pop(0)
    
    @staticmethod
    def set_weights(user_weights: Dict[str, int]):
        """Set distribution weights for users"""
        LeadDistributionService.distribution_rules["weights"] = user_weights
    
    @staticmethod
    def get_distribution_history(limit: int = 20) -> List[Dict]:
        """Get recent distribution history"""
        return LeadDistributionService.distribution_history[-limit:]
    
    @staticmethod
    def get_user_stats(user_id: str) -> Dict:
        """Get distribution stats for a user"""
        received = sum(
            1 for d in LeadDistributionService.distribution_history 
            if user_id in d.get("to_users", [])
        )
        sent = sum(
            1 for d in LeadDistributionService.distribution_history 
            if d.get("from_user") == user_id
        )
        return {"received": received, "sent": sent}
