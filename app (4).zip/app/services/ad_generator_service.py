"""Ultimate Ad Generator - 8 Unicorn Strategies for 100x ROI"""
import os
import base64
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

# Geographic targeting data
GEO_LOCATIONS = {
    "EG": {
        "name": "مصر",
        "code": "EG",
        "cities": [
            {"key": "cairo", "name": "القاهرة", "radius": 25},
            {"key": "alexandria", "name": "الإسكندرية", "radius": 20},
            {"key": "giza", "name": "الجيزة", "radius": 20},
            {"key": "sharm", "name": "شرم الشيخ", "radius": 15},
            {"key": "hurghada", "name": "الغردقة", "radius": 15},
            {"key": "luxor", "name": "الأقصر", "radius": 15},
            {"key": "aswan", "name": "أسوان", "radius": 15},
            {"key": "mansoura", "name": "المنصورة", "radius": 15},
            {"key": "tanta", "name": "طنطا", "radius": 15},
            {"key": "ismailia", "name": "الإسماعيلية", "radius": 15},
        ]
    },
    "SA": {
        "name": "السعودية",
        "code": "SA",
        "cities": [
            {"key": "riyadh", "name": "الرياض", "radius": 30},
            {"key": "jeddah", "name": "جدة", "radius": 25},
            {"key": "mecca", "name": "مكة", "radius": 20},
            {"key": "medina", "name": "المدينة", "radius": 20},
            {"key": "dammam", "name": "الدمام", "radius": 20},
            {"key": "khobar", "name": "الخبر", "radius": 15},
        ]
    },
    "AE": {
        "name": "الإمارات",
        "code": "AE",
        "cities": [
            {"key": "dubai", "name": "دبي", "radius": 25},
            {"key": "abudhabi", "name": "أبوظبي", "radius": 25},
            {"key": "sharjah", "name": "الشارقة", "radius": 15},
        ]
    },
    "KW": {"name": "الكويت", "code": "KW", "cities": []},
    "QA": {"name": "قطر", "code": "QA", "cities": []},
    "BH": {"name": "البحرين", "code": "BH", "cities": []},
    "OM": {"name": "عُمان", "code": "OM", "cities": []},
    "JO": {"name": "الأردن", "code": "JO", "cities": []},
    "LB": {"name": "لبنان", "code": "LB", "cities": []},
    "IQ": {"name": "العراق", "code": "IQ", "cities": []},
    "MA": {"name": "المغرب", "code": "MA", "cities": []},
    "DZ": {"name": "الجزائر", "code": "DZ", "cities": []},
    "TN": {"name": "تونس", "code": "TN", "cities": []},
}

# Budget estimation data (CPM by country - cost per 1000 impressions)
CPM_RATES = {
    "EG": {"min": 0.5, "max": 2.0, "avg": 1.0, "currency": "USD"},
    "SA": {"min": 2.0, "max": 8.0, "avg": 4.0, "currency": "USD"},
    "AE": {"min": 3.0, "max": 10.0, "avg": 5.0, "currency": "USD"},
    "KW": {"min": 2.5, "max": 8.0, "avg": 4.5, "currency": "USD"},
    "QA": {"min": 2.5, "max": 8.0, "avg": 4.5, "currency": "USD"},
    "default": {"min": 1.0, "max": 5.0, "avg": 2.5, "currency": "USD"},
}

try:
    from app.services.ad_learning_service import ad_learning_service
    AD_LEARNING_AVAILABLE = True
except ImportError:
    ad_learning_service = None
    AD_LEARNING_AVAILABLE = False


UNICORN_STRATEGIES = {
    "nano_influencer": {
        "name": "Nano Influencer",
        "name_ar": "استراتيجية النانو إنفلونسر",
        "description": "استخدام أسلوب المؤثرين الصغار - محتوى طبيعي وموثوق",
        "template": """
🎯 {headline}

أنا جربت {product} وصراحة النتيجة فاجأتني! 😍

{benefit_1}
{benefit_2}
{benefit_3}

لو عايز تجرب زيي، كلمهم دلوقتي 👇
{cta}
""",
        "tone": "casual",
        "emoji_level": "high"
    },
    "ugc_factory": {
        "name": "UGC Factory",
        "name_ar": "مصنع المحتوى الحقيقي",
        "description": "محتوى يبدو كأنه من عميل حقيقي - أعلى CTR",
        "template": """
📱 قصتي مع {product}...

كنت فاكر إنه هيكون زي أي حاجة تانية، بس الحقيقة إني اتفاجأت! 

✅ {benefit_1}
✅ {benefit_2}  
✅ {benefit_3}

النتيجة؟ {result}

تواصل معاهم دلوقتي 👇
{cta}
""",
        "tone": "authentic",
        "emoji_level": "medium"
    },
    "viral_hook": {
        "name": "Viral Hook",
        "name_ar": "الخطاف الفيروسي",
        "description": "بداية صادمة تجبر المشاهد على التوقف",
        "template": """
🔥 توقف ثانية واحدة!

{shocking_statement}

{product} هو الحل اللي كنت بتدور عليه طول الوقت.

لأن:
• {benefit_1}
• {benefit_2}
• {benefit_3}

{urgency}

{cta}
""",
        "tone": "urgent",
        "emoji_level": "high"
    },
    "problem_amplify": {
        "name": "Problem Amplify",
        "name_ar": "تضخيم المشكلة",
        "description": "تكبير الألم ثم تقديم الحل - نفسياً الأقوى",
        "template": """
😰 هل أنت عايش المشكلة دي؟

{problem_statement}

كل يوم بتفوت عليك الفرصة...
كل يوم المشكلة بتكبر...

❌ {pain_point_1}
❌ {pain_point_2}
❌ {pain_point_3}

بس في حل واحد...

✅ {product}

{cta}
""",
        "tone": "empathetic",
        "emoji_level": "medium"
    },
    "real_scarcity": {
        "name": "Real Scarcity",
        "name_ar": "الندرة الحقيقية",
        "description": "عروض محدودة فعلاً - تحفز الشراء الفوري",
        "template": """
⚠️ تنبيه مهم!

{scarcity_statement}

{product} متاح دلوقتي بعرض خاص:

🎁 {offer}

⏰ العرض ينتهي: {deadline}
📦 الكمية المتبقية: محدودة جداً

احجز مكانك دلوقتي 👇
{cta}
""",
        "tone": "urgent",
        "emoji_level": "high"
    },
    "social_proof": {
        "name": "Social Proof",
        "name_ar": "الإثبات الاجتماعي",
        "description": "عرض نجاحات العملاء السابقين",
        "template": """
⭐⭐⭐⭐⭐

"{testimonial}"
- {customer_name}

مش لوحده... {customer_count}+ عميل اختاروا {product}

لأن:
✅ {benefit_1}
✅ {benefit_2}
✅ {benefit_3}

انضم ليهم دلوقتي 👇
{cta}
""",
        "tone": "trustworthy",
        "emoji_level": "medium"
    },
    "pixel_optimization": {
        "name": "Pixel Optimization",
        "name_ar": "استهداف البيكسل الذكي",
        "description": "إعلان مُحسَّن لخوارزمية فيسبوك",
        "template": """
🎯 خصيصاً ليك!

لأنك مهتم بـ {interest}...

{product} هيساعدك تحقق:

1️⃣ {benefit_1}
2️⃣ {benefit_2}
3️⃣ {benefit_3}

🔥 عرض خاص لفترة محدودة

{cta}
""",
        "tone": "personalized",
        "emoji_level": "medium"
    },
    "retarget_ladder": {
        "name": "Retarget Ladder",
        "name_ar": "سلم إعادة الاستهداف",
        "description": "سلسلة إعلانات متدرجة للعملاء المترددين",
        "template": """
👋 شكلك مهتم بـ {product}...

وإحنا مهتمين بيك كمان! 😊

عشان كده جهزنالك عرض خاص:

🎁 {special_offer}

{benefit_1}
{benefit_2}

العرض لفترة محدودة ⏰

{cta}
""",
        "tone": "friendly",
        "emoji_level": "high"
    }
}


class AdGeneratorService:
    """AI-Powered Ad Generator with 8 Unicorn Strategies"""
    
    def __init__(self):
        self.strategies = UNICORN_STRATEGIES
        self.openai_key = OPENAI_API_KEY
    
    async def generate_buyer_persona(
        self,
        business_type: str,
        product_service: str,
        location: str = "مصر",
        custom_details: str = ""
    ) -> Dict[str, Any]:
        """Generate AI buyer persona based on business info"""
        
        prompt = f"""أنت خبير تسويق وإعلانات. حلل البيزنس ده واقترح الجمهور المستهدف المثالي:

البيزنس: {business_type}
المنتج/الخدمة: {product_service}
الموقع: {location}
تفاصيل إضافية: {custom_details}

اكتب الرد بالعربي في JSON format:
{{
    "age_min": 18,
    "age_max": 45,
    "genders": [1, 2],
    "countries": ["EG"],
    "cities": [],
    "interests": ["اهتمام 1", "اهتمام 2", "اهتمام 3"],
    "behaviors": ["سلوك 1", "سلوك 2"],
    "pain_points": ["مشكلة 1", "مشكلة 2", "مشكلة 3"],
    "desires": ["رغبة 1", "رغبة 2", "رغبة 3"],
    "buying_triggers": ["محفز 1", "محفز 2"],
    "objections": ["اعتراض 1", "اعتراض 2"],
    "persona_name": "اسم الشخصية",
    "persona_description": "وصف قصير للعميل المثالي"
}}
"""
        
        try:
            if self.openai_key:
                from openai import OpenAI
                client = OpenAI(api_key=self.openai_key)
                
                response = client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.7
                )
                
                content = response.choices[0].message.content
                import json
                import re
                json_match = re.search(r'\{[\s\S]*\}', content)
                if json_match:
                    persona = json.loads(json_match.group())
                    persona["generated"] = True
                    return persona
        except Exception as e:
            print(f"AI persona error: {e}")
        
        return self._default_persona(business_type, location)
    
    def _default_persona(self, business_type: str, location: str) -> Dict[str, Any]:
        """Default buyer persona if AI fails"""
        return {
            "age_min": 25,
            "age_max": 45,
            "genders": [1, 2],
            "countries": ["EG"] if "مصر" in location else ["SA"],
            "cities": [],
            "interests": ["تسوق", "أعمال", "تكنولوجيا"],
            "behaviors": ["مشترين نشطين", "مستخدمي موبايل"],
            "pain_points": ["الوقت", "الجودة", "السعر"],
            "desires": ["توفير", "جودة عالية", "سرعة"],
            "buying_triggers": ["عروض", "ضمان"],
            "objections": ["السعر عالي", "مش متأكد"],
            "persona_name": "العميل المثالي",
            "persona_description": f"عميل مهتم بـ {business_type} في {location}",
            "generated": False
        }
    
    async def generate_ad_content(
        self,
        business_name: str,
        product_service: str,
        buyer_persona: Dict[str, Any],
        strategy: str = "viral_hook",
        whatsapp_number: str = "",
        custom_offer: str = "",
        user_id: str = ""
    ) -> Dict[str, Any]:
        """Generate ad content using selected Unicorn strategy + learned patterns"""
        
        strategy_info = self.strategies.get(strategy, self.strategies["viral_hook"])
        
        learned_context = ""
        if AD_LEARNING_AVAILABLE and ad_learning_service and user_id:
            patterns = ad_learning_service.get_learned_patterns(user_id)
            if patterns:
                top_patterns = patterns.get("patterns", [])[:3]
                if top_patterns:
                    learned_context = f"""
📊 تعلمت من إعلاناتك السابقة الناجحة:
- أفضل العناوين: {[p.get('headline', '') for p in top_patterns if p.get('headline')]}
- أفضل CTAs: {[p.get('cta', '') for p in top_patterns if p.get('cta')]}
- متوسط CTR الناجح: {max([p.get('ctr', 0) for p in top_patterns])}%

استخدم نفس الأسلوب والنبرة من الإعلانات الناجحة دي.
"""
        
        prompt = f"""أنت كاتب إعلانات خبير. اكتب إعلان قوي جداً بالعربي المصري.
{learned_context}

البيزنس: {business_name}
المنتج/الخدمة: {product_service}
الاستراتيجية: {strategy_info['name_ar']}
العرض: {custom_offer if custom_offer else 'عرض خاص لفترة محدودة'}

الجمهور المستهدف:
- الفئة العمرية: {buyer_persona.get('age_min', 25)} - {buyer_persona.get('age_max', 45)}
- المشاكل: {', '.join(buyer_persona.get('pain_points', []))}
- الرغبات: {', '.join(buyer_persona.get('desires', []))}

الـ CTA: تواصل واتساب على {whatsapp_number}

اكتب:
1. عنوان رئيسي جذاب (headline) - سطر واحد
2. 3 عناوين بديلة (alt_headlines)
3. نص الإعلان الكامل (body) - استخدم الاستراتيجية
4. Call to Action قوي

الرد بـ JSON:
{{
    "headline": "العنوان الرئيسي",
    "alt_headlines": ["بديل 1", "بديل 2", "بديل 3"],
    "body": "نص الإعلان الكامل",
    "cta": "Call to Action",
    "hashtags": ["#هاشتاج1", "#هاشتاج2"]
}}
"""
        
        try:
            if self.openai_key:
                from openai import OpenAI
                client = OpenAI(api_key=self.openai_key)
                
                response = client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.8
                )
                
                content = response.choices[0].message.content
                import json
                import re
                json_match = re.search(r'\{[\s\S]*\}', content)
                if json_match:
                    ad_content = json.loads(json_match.group())
                    ad_content["strategy"] = strategy
                    ad_content["strategy_name"] = strategy_info["name_ar"]
                    ad_content["whatsapp_link"] = f"https://wa.me/{whatsapp_number.replace('+', '').replace(' ', '')}"
                    return ad_content
        except Exception as e:
            print(f"AI ad generation error: {e}")
        
        return self._default_ad(business_name, product_service, whatsapp_number, strategy_info)
    
    def _default_ad(
        self,
        business_name: str,
        product_service: str,
        whatsapp_number: str,
        strategy_info: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Default ad if AI fails"""
        return {
            "headline": f"🔥 عرض خاص من {business_name}!",
            "alt_headlines": [
                f"✨ اكتشف {product_service} الآن",
                f"🎯 {business_name} - جودة تفوق التوقعات",
                f"⭐ العرض الأقوى من {business_name}"
            ],
            "body": f"""🔥 عرض مميز من {business_name}!

{product_service} بجودة عالية وأسعار مناسبة.

✅ جودة مضمونة
✅ خدمة سريعة
✅ أسعار منافسة

⏰ العرض لفترة محدودة!

تواصل معانا دلوقتي 👇""",
            "cta": f"📱 تواصل واتساب: {whatsapp_number}",
            "hashtags": [f"#{business_name.replace(' ', '_')}", "#عروض", "#مصر"],
            "strategy": strategy_info.get("name", "viral_hook"),
            "strategy_name": strategy_info.get("name_ar", "الخطاف الفيروسي"),
            "whatsapp_link": f"https://wa.me/{whatsapp_number.replace('+', '').replace(' ', '')}"
        }
    
    async def generate_multiple_ads(
        self,
        business_name: str,
        product_service: str,
        buyer_persona: Dict[str, Any],
        whatsapp_number: str,
        strategies: List[str] = None
    ) -> List[Dict[str, Any]]:
        """Generate multiple ads with different strategies for A/B testing"""
        
        if not strategies:
            strategies = ["viral_hook", "ugc_factory", "social_proof"]
        
        ads = []
        for strategy in strategies:
            ad = await self.generate_ad_content(
                business_name=business_name,
                product_service=product_service,
                buyer_persona=buyer_persona,
                strategy=strategy,
                whatsapp_number=whatsapp_number
            )
            ads.append(ad)
        
        return ads
    
    def get_all_strategies(self) -> List[Dict[str, Any]]:
        """Get list of all available strategies"""
        return [
            {
                "id": key,
                "name": val["name"],
                "name_ar": val["name_ar"],
                "description": val["description"]
            }
            for key, val in self.strategies.items()
        ]
    
    def get_geo_locations(self) -> Dict[str, Any]:
        """Get all available geographic locations for targeting"""
        return GEO_LOCATIONS
    
    async def suggest_image_ideas(
        self,
        business_name: str,
        product_service: str,
        strategy: str = "viral_hook"
    ) -> Dict[str, Any]:
        """AI suggests best image ideas when user doesn't upload any"""
        
        prompt = f"""أنت خبير تصميم إعلانات. اقترح أفكار صور/فيديو للإعلان ده:

البيزنس: {business_name}
المنتج/الخدمة: {product_service}
استراتيجية الإعلان: {self.strategies.get(strategy, {}).get('name_ar', 'فيروسي')}

اقترح:
1. 3 أفكار صور (وصف دقيق لكل صورة)
2. 2 أفكار فيديو قصير (وصف + مدة)
3. ألوان مقترحة
4. نص على الصورة (إن وجد)
5. مصادر صور مجانية مناسبة

الرد بـ JSON:
{{
    "image_ideas": [
        {{"description": "وصف الصورة", "style": "نوع الستايل", "elements": ["عنصر 1", "عنصر 2"]}},
    ],
    "video_ideas": [
        {{"description": "وصف الفيديو", "duration": "15 ثانية", "scenes": ["مشهد 1", "مشهد 2"]}}
    ],
    "colors": {{"primary": "#HEX", "secondary": "#HEX", "accent": "#HEX"}},
    "text_overlay": "النص المقترح على الصورة",
    "text_position": "bottom",
    "free_image_sources": ["pexels.com", "unsplash.com"],
    "search_keywords": ["كلمة بحث 1", "كلمة بحث 2"]
}}
"""
        
        try:
            if self.openai_key:
                from openai import OpenAI
                client = OpenAI(api_key=self.openai_key)
                
                response = client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.8
                )
                
                content = response.choices[0].message.content
                import json
                import re
                json_match = re.search(r'\{[\s\S]*\}', content)
                if json_match:
                    suggestions = json.loads(json_match.group())
                    suggestions["has_suggestions"] = True
                    return suggestions
        except Exception as e:
            print(f"Image suggestion error: {e}")
        
        return self._default_image_suggestions(business_name, product_service)
    
    def _default_image_suggestions(self, business_name: str, product_service: str) -> Dict[str, Any]:
        """Default image suggestions if AI fails"""
        return {
            "has_suggestions": True,
            "image_ideas": [
                {"description": f"صورة احترافية لـ {product_service}", "style": "professional", "elements": ["المنتج", "خلفية بيضاء"]},
                {"description": "شخص سعيد يستخدم المنتج", "style": "lifestyle", "elements": ["ابتسامة", "استخدام حقيقي"]},
                {"description": "Before & After للنتيجة", "style": "comparison", "elements": ["قبل", "بعد", "سهم"]}
            ],
            "video_ideas": [
                {"description": "فيديو قصير للمنتج", "duration": "15 ثانية", "scenes": ["المنتج", "الاستخدام", "النتيجة"]},
                {"description": "شهادة عميل", "duration": "30 ثانية", "scenes": ["العميل يتكلم", "النتيجة"]}
            ],
            "colors": {"primary": "#FF6B35", "secondary": "#1A1A2E", "accent": "#FFD700"},
            "text_overlay": f"🔥 عرض خاص من {business_name}!",
            "text_position": "bottom",
            "free_image_sources": ["pexels.com", "unsplash.com", "pixabay.com"],
            "search_keywords": [business_name, product_service, "professional", "modern"]
        }
    
    async def generate_complete_ad(
        self,
        business_name: str,
        product_service: str,
        whatsapp_number: str,
        strategy: str = "viral_hook",
        custom_offer: str = "",
        has_media: bool = False,
        user_id: str = ""
    ) -> Dict[str, Any]:
        """Generate complete ad with content + image suggestions if no media"""
        
        buyer_persona = await self.generate_buyer_persona(
            business_type=business_name,
            product_service=product_service
        )
        
        ad_content = await self.generate_ad_content(
            business_name=business_name,
            product_service=product_service,
            buyer_persona=buyer_persona,
            strategy=strategy,
            whatsapp_number=whatsapp_number,
            custom_offer=custom_offer,
            user_id=user_id
        )
        
        result = {
            "ad_content": ad_content,
            "buyer_persona": buyer_persona,
            "strategy_used": strategy,
            "complete": True
        }
        
        if not has_media:
            image_suggestions = await self.suggest_image_ideas(
                business_name=business_name,
                product_service=product_service,
                strategy=strategy
            )
            result["image_suggestions"] = image_suggestions
            result["no_media_message"] = "🎨 مش لازم ترفع صور! استخدم الاقتراحات دي أو نزل صور من المصادر المجانية"
        
        return result
    
    def estimate_budget(
        self,
        daily_budget: float,
        duration_days: int,
        countries: List[str],
        objective: str = "CONVERSIONS"
    ) -> Dict[str, Any]:
        """Estimate ad campaign costs and reach"""
        
        total_budget = daily_budget * duration_days
        
        avg_cpm = 0
        for country in countries:
            cpm = CPM_RATES.get(country, CPM_RATES["default"])
            avg_cpm += cpm["avg"]
        avg_cpm = avg_cpm / len(countries) if countries else CPM_RATES["default"]["avg"]
        
        estimated_impressions_min = int((total_budget / avg_cpm) * 1000 * 0.7)
        estimated_impressions_max = int((total_budget / avg_cpm) * 1000 * 1.3)
        
        ctr_rates = {
            "CONVERSIONS": 0.015,
            "TRAFFIC": 0.02,
            "ENGAGEMENT": 0.025,
            "REACH": 0.01,
            "MESSAGES": 0.018
        }
        ctr = ctr_rates.get(objective, 0.015)
        
        estimated_clicks_min = int(estimated_impressions_min * ctr)
        estimated_clicks_max = int(estimated_impressions_max * ctr)
        
        conversion_rate = 0.03
        estimated_leads_min = int(estimated_clicks_min * conversion_rate)
        estimated_leads_max = int(estimated_clicks_max * conversion_rate)
        
        cost_per_click_min = total_budget / estimated_clicks_max if estimated_clicks_max > 0 else 0
        cost_per_click_max = total_budget / estimated_clicks_min if estimated_clicks_min > 0 else 0
        
        return {
            "daily_budget": daily_budget,
            "total_budget": total_budget,
            "duration_days": duration_days,
            "currency": "USD",
            "estimated_impressions": {
                "min": estimated_impressions_min,
                "max": estimated_impressions_max
            },
            "estimated_clicks": {
                "min": estimated_clicks_min,
                "max": estimated_clicks_max
            },
            "estimated_leads": {
                "min": estimated_leads_min,
                "max": estimated_leads_max
            },
            "cost_per_click": {
                "min": round(cost_per_click_min, 2),
                "max": round(cost_per_click_max, 2)
            },
            "avg_cpm": round(avg_cpm, 2),
            "objective": objective
        }
    
    async def generate_targeting_from_ai(
        self,
        business_type: str,
        product_service: str,
        buyer_persona: Dict[str, Any]
    ) -> Dict[str, Any]:
        """AI generates optimal geographic targeting"""
        
        prompt = f"""أنت خبير إعلانات فيسبوك. بناءً على البيزنس ده، اقترح أفضل استهداف جغرافي:

البيزنس: {business_type}
المنتج/الخدمة: {product_service}
الجمهور المستهدف: {buyer_persona.get('persona_description', '')}

اختر من الدول دي: مصر (EG), السعودية (SA), الإمارات (AE), الكويت (KW), قطر (QA), البحرين (BH), الأردن (JO), لبنان (LB), المغرب (MA)

الرد بـ JSON:
{{
    "recommended_countries": ["EG"],
    "recommended_cities": ["cairo", "alexandria"],
    "reasoning": "السبب في اختيار المواقع دي",
    "audience_size_estimate": "500K - 2M"
}}
"""
        
        try:
            if self.openai_key:
                from openai import OpenAI
                client = OpenAI(api_key=self.openai_key)
                
                response = client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.6
                )
                
                content = response.choices[0].message.content
                import json
                import re
                json_match = re.search(r'\{[\s\S]*\}', content)
                if json_match:
                    return json.loads(json_match.group())
        except Exception as e:
            print(f"AI targeting error: {e}")
        
        return {
            "recommended_countries": ["EG"],
            "recommended_cities": ["cairo", "alexandria", "giza"],
            "reasoning": "مصر هي أكبر سوق عربي مع قوة شرائية متنامية",
            "audience_size_estimate": "1M - 5M"
        }
    
    async def transcribe_voice_to_ad(self, audio_base64: str) -> Dict[str, Any]:
        """Convert voice recording to ad content using AI"""
        
        try:
            if self.openai_key:
                from openai import OpenAI
                import tempfile
                
                client = OpenAI(api_key=self.openai_key)
                
                audio_data = base64.b64decode(audio_base64)
                
                with tempfile.NamedTemporaryFile(suffix=".webm", delete=False) as f:
                    f.write(audio_data)
                    temp_path = f.name
                
                with open(temp_path, "rb") as audio_file:
                    transcript = client.audio.transcriptions.create(
                        model="whisper-1",
                        file=audio_file,
                        language="ar"
                    )
                
                os.unlink(temp_path)
                
                transcribed_text = transcript.text
                
                parse_prompt = f"""حلل الكلام ده واستخرج معلومات الإعلان:

الكلام: "{transcribed_text}"

استخرج:
1. اسم البيزنس/المنتج
2. وصف المنتج/الخدمة
3. العرض أو الـ Offer
4. رقم الواتساب (لو موجود)
5. أي تفاصيل مهمة

الرد بـ JSON:
{{
    "business_name": "",
    "product_service": "",
    "offer": "",
    "whatsapp": "",
    "details": "",
    "transcribed_text": "{transcribed_text}"
}}
"""
                
                parse_response = client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[{"role": "user", "content": parse_prompt}],
                    temperature=0.3
                )
                
                content = parse_response.choices[0].message.content
                import json
                import re
                json_match = re.search(r'\{[\s\S]*\}', content)
                if json_match:
                    parsed = json.loads(json_match.group())
                    parsed["success"] = True
                    parsed["transcribed_text"] = transcribed_text
                    return parsed
                
                return {
                    "success": True,
                    "transcribed_text": transcribed_text,
                    "business_name": "",
                    "product_service": transcribed_text,
                    "offer": "",
                    "whatsapp": "",
                    "details": ""
                }
                
        except Exception as e:
            print(f"Voice transcription error: {e}")
            return {
                "success": False,
                "error": str(e),
                "transcribed_text": ""
            }
    
    def validate_media_for_ad(self, media_type: str, file_size: int, dimensions: tuple = None) -> Dict[str, Any]:
        """Validate media files for Facebook ads"""
        
        specs = {
            "image": {
                "max_size_mb": 30,
                "formats": ["jpg", "jpeg", "png"],
                "min_width": 600,
                "min_height": 600,
                "aspect_ratios": ["1:1", "4:5", "9:16", "16:9"]
            },
            "video": {
                "max_size_mb": 4096,
                "formats": ["mp4", "mov"],
                "min_duration": 1,
                "max_duration": 240,
                "min_width": 600
            },
            "carousel": {
                "max_images": 10,
                "min_images": 2,
                "same_aspect_ratio": True
            }
        }
        
        spec = specs.get(media_type, specs["image"])
        max_bytes = spec["max_size_mb"] * 1024 * 1024
        
        issues = []
        if file_size > max_bytes:
            issues.append(f"حجم الملف كبير جداً. الحد الأقصى: {spec['max_size_mb']} MB")
        
        if dimensions and media_type == "image":
            w, h = dimensions
            if w < spec["min_width"] or h < spec["min_height"]:
                issues.append(f"الأبعاد صغيرة. الحد الأدنى: {spec['min_width']}x{spec['min_height']}")
        
        return {
            "valid": len(issues) == 0,
            "issues": issues,
            "specs": spec
        }


ad_generator_service = AdGeneratorService()
