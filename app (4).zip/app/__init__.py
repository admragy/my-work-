"""Hunter Pro CRM - AI-Powered Lead Generation System"""
__version__ = "3.0.0"
