"""Meta Ads Service - Facebook/Instagram Ads Integration"""
import os
import json
from typing import Dict, Any, Optional, List
from datetime import datetime

try:
    from facebook_business.api import FacebookAdsApi
    from facebook_business.adobjects.adaccount import AdAccount
    from facebook_business.adobjects.campaign import Campaign
    from facebook_business.adobjects.adset import AdSet
    from facebook_business.adobjects.ad import Ad
    from facebook_business.adobjects.adcreative import AdCreative
    from facebook_business.adobjects.page import Page
    from facebook_business.exceptions import FacebookRequestError
    META_SDK_AVAILABLE = True
except ImportError:
    META_SDK_AVAILABLE = False

META_APP_ID = os.getenv("META_APP_ID", "")
META_APP_SECRET = os.getenv("META_APP_SECRET", "")


class MetaAdsService:
    """Service for creating and managing Meta (Facebook/Instagram) Ads"""
    
    def __init__(self):
        self.app_id = META_APP_ID
        self.app_secret = META_APP_SECRET
        self.sdk_available = META_SDK_AVAILABLE
        
    def get_login_url(self, redirect_uri: str) -> str:
        """Generate Facebook OAuth login URL"""
        scopes = [
            "pages_show_list",
            "pages_read_engagement", 
            "ads_management",
            "ads_read",
            "business_management"
        ]
        scope_str = ",".join(scopes)
        
        login_url = (
            f"https://www.facebook.com/v18.0/dialog/oauth?"
            f"client_id={self.app_id}"
            f"&redirect_uri={redirect_uri}"
            f"&scope={scope_str}"
            f"&response_type=code"
        )
        return login_url
    
    def exchange_code_for_token(self, code: str, redirect_uri: str) -> Dict[str, Any]:
        """Exchange authorization code for access token"""
        import requests
        
        url = "https://graph.facebook.com/v18.0/oauth/access_token"
        params = {
            "client_id": self.app_id,
            "client_secret": self.app_secret,
            "redirect_uri": redirect_uri,
            "code": code
        }
        
        try:
            response = requests.get(url, params=params)
            data = response.json()
            
            if "access_token" in data:
                return {
                    "success": True,
                    "access_token": data["access_token"],
                    "expires_in": data.get("expires_in", 0)
                }
            else:
                return {
                    "success": False,
                    "error": data.get("error", {}).get("message", "Unknown error")
                }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def get_user_pages(self, access_token: str) -> List[Dict[str, Any]]:
        """Get list of pages user manages"""
        import requests
        
        url = "https://graph.facebook.com/v18.0/me/accounts"
        params = {"access_token": access_token}
        
        try:
            response = requests.get(url, params=params)
            data = response.json()
            
            pages = []
            for page in data.get("data", []):
                pages.append({
                    "id": page["id"],
                    "name": page["name"],
                    "access_token": page.get("access_token", "")
                })
            return pages
        except Exception as e:
            print(f"Error getting pages: {e}")
            return []
    
    def get_ad_accounts(self, access_token: str) -> List[Dict[str, Any]]:
        """Get list of ad accounts user has access to"""
        import requests
        
        url = "https://graph.facebook.com/v18.0/me/adaccounts"
        params = {
            "access_token": access_token,
            "fields": "id,name,account_status,currency"
        }
        
        try:
            response = requests.get(url, params=params)
            data = response.json()
            
            accounts = []
            for acc in data.get("data", []):
                accounts.append({
                    "id": acc["id"],
                    "name": acc.get("name", "Unknown"),
                    "status": acc.get("account_status", 0),
                    "currency": acc.get("currency", "USD")
                })
            return accounts
        except Exception as e:
            print(f"Error getting ad accounts: {e}")
            return []
    
    def create_campaign(
        self,
        access_token: str,
        ad_account_id: str,
        name: str,
        objective: str = "OUTCOME_LEADS",
        status: str = "PAUSED"
    ) -> Dict[str, Any]:
        """Create a new campaign"""
        if not self.sdk_available:
            return {"success": False, "error": "Meta SDK not available"}
        
        try:
            FacebookAdsApi.init(self.app_id, self.app_secret, access_token)
            
            campaign_params = {
                Campaign.Field.name: name,
                Campaign.Field.objective: objective,
                Campaign.Field.status: status,
                Campaign.Field.special_ad_categories: []
            }
            
            campaign = AdAccount(ad_account_id).create_campaign(
                fields=[],
                params=campaign_params
            )
            
            return {
                "success": True,
                "campaign_id": campaign["id"],
                "name": name
            }
        except FacebookRequestError as e:
            return {
                "success": False,
                "error": e.api_error_message(),
                "error_code": e.api_error_code()
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def create_ad_set(
        self,
        access_token: str,
        ad_account_id: str,
        campaign_id: str,
        name: str,
        targeting: Dict[str, Any],
        daily_budget: int = 1000,
        optimization_goal: str = "LEAD_GENERATION"
    ) -> Dict[str, Any]:
        """Create ad set with targeting"""
        if not self.sdk_available:
            return {"success": False, "error": "Meta SDK not available"}
        
        try:
            FacebookAdsApi.init(self.app_id, self.app_secret, access_token)
            
            adset_params = {
                AdSet.Field.name: name,
                AdSet.Field.campaign_id: campaign_id,
                AdSet.Field.billing_event: "IMPRESSIONS",
                AdSet.Field.optimization_goal: optimization_goal,
                AdSet.Field.daily_budget: daily_budget,
                AdSet.Field.targeting: targeting,
                AdSet.Field.status: "PAUSED"
            }
            
            adset = AdAccount(ad_account_id).create_ad_set(
                fields=[],
                params=adset_params
            )
            
            return {
                "success": True,
                "adset_id": adset["id"],
                "name": name
            }
        except FacebookRequestError as e:
            return {
                "success": False,
                "error": e.api_error_message(),
                "error_code": e.api_error_code()
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def create_whatsapp_ad(
        self,
        access_token: str,
        ad_account_id: str,
        page_id: str,
        adset_id: str,
        ad_name: str,
        headline: str,
        body_text: str,
        whatsapp_number: str,
        cta_text: str = "تواصل عبر واتساب",
        image_url: str = None
    ) -> Dict[str, Any]:
        """Create ad with WhatsApp CTA"""
        if not self.sdk_available:
            return {"success": False, "error": "Meta SDK not available"}
        
        try:
            FacebookAdsApi.init(self.app_id, self.app_secret, access_token)
            
            whatsapp_link = f"https://wa.me/{whatsapp_number.replace('+', '').replace(' ', '')}"
            
            link_data = {
                "message": body_text,
                "link": whatsapp_link,
                "name": headline,
                "call_to_action": {
                    "type": "WHATSAPP_MESSAGE",
                    "value": {
                        "whatsapp_number": whatsapp_number
                    }
                }
            }
            
            if image_url:
                link_data["picture"] = image_url
            
            creative_params = {
                AdCreative.Field.name: f"Creative - {ad_name}",
                AdCreative.Field.object_story_spec: {
                    "page_id": page_id,
                    "link_data": link_data
                }
            }
            
            creative = AdAccount(ad_account_id).create_ad_creative(
                fields=[],
                params=creative_params
            )
            
            ad_params = {
                Ad.Field.name: ad_name,
                Ad.Field.adset_id: adset_id,
                Ad.Field.creative: {"creative_id": creative["id"]},
                Ad.Field.status: "PAUSED"
            }
            
            ad = AdAccount(ad_account_id).create_ad(
                fields=[],
                params=ad_params
            )
            
            return {
                "success": True,
                "ad_id": ad["id"],
                "creative_id": creative["id"],
                "whatsapp_link": whatsapp_link
            }
        except FacebookRequestError as e:
            return {
                "success": False,
                "error": e.api_error_message(),
                "error_code": e.api_error_code()
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def create_full_ad_campaign(
        self,
        access_token: str,
        ad_account_id: str,
        page_id: str,
        business_info: Dict[str, Any],
        buyer_persona: Dict[str, Any],
        ad_content: Dict[str, Any],
        whatsapp_number: str,
        daily_budget: int = 1000
    ) -> Dict[str, Any]:
        """Create complete ad campaign with all components"""
        
        business_name = business_info.get("name", "Business")
        
        campaign_result = self.create_campaign(
            access_token=access_token,
            ad_account_id=ad_account_id,
            name=f"حملة {business_name} - {datetime.now().strftime('%Y-%m-%d')}",
            objective="OUTCOME_LEADS"
        )
        
        if not campaign_result.get("success"):
            return campaign_result
        
        targeting = self._build_targeting(buyer_persona)
        
        adset_result = self.create_ad_set(
            access_token=access_token,
            ad_account_id=ad_account_id,
            campaign_id=campaign_result["campaign_id"],
            name=f"إعلان {business_name}",
            targeting=targeting,
            daily_budget=daily_budget
        )
        
        if not adset_result.get("success"):
            return adset_result
        
        ad_result = self.create_whatsapp_ad(
            access_token=access_token,
            ad_account_id=ad_account_id,
            page_id=page_id,
            adset_id=adset_result["adset_id"],
            ad_name=ad_content.get("headline", "إعلان"),
            headline=ad_content.get("headline", ""),
            body_text=ad_content.get("body", ""),
            whatsapp_number=whatsapp_number,
            image_url=ad_content.get("image_url")
        )
        
        if not ad_result.get("success"):
            return ad_result
        
        return {
            "success": True,
            "campaign_id": campaign_result["campaign_id"],
            "adset_id": adset_result["adset_id"],
            "ad_id": ad_result["ad_id"],
            "whatsapp_link": ad_result["whatsapp_link"],
            "status": "PAUSED",
            "message": "تم إنشاء الحملة بنجاح! اضغط 'تفعيل' لبدء الإعلان."
        }
    
    def _build_targeting(self, buyer_persona: Dict[str, Any]) -> Dict[str, Any]:
        """Build Meta targeting from buyer persona"""
        targeting = {
            "geo_locations": {},
            "age_min": buyer_persona.get("age_min", 18),
            "age_max": buyer_persona.get("age_max", 65)
        }
        
        countries = buyer_persona.get("countries", ["EG"])
        if countries:
            targeting["geo_locations"]["countries"] = countries
        
        cities = buyer_persona.get("cities", [])
        if cities:
            targeting["geo_locations"]["cities"] = cities
        
        genders = buyer_persona.get("genders", [])
        if genders:
            targeting["genders"] = genders
        
        interests = buyer_persona.get("interests", [])
        if interests:
            targeting["interests"] = interests
        
        return targeting
    
    def activate_campaign(self, access_token: str, campaign_id: str) -> Dict[str, Any]:
        """Activate a paused campaign"""
        if not self.sdk_available:
            return {"success": False, "error": "Meta SDK not available"}
        
        try:
            FacebookAdsApi.init(self.app_id, self.app_secret, access_token)
            
            campaign = Campaign(campaign_id)
            campaign.api_update(
                fields=[],
                params={Campaign.Field.status: "ACTIVE"}
            )
            
            return {"success": True, "status": "ACTIVE"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def get_campaign_insights(
        self,
        access_token: str,
        campaign_id: str,
        date_preset: str = "last_7d"
    ) -> Dict[str, Any]:
        """Get campaign performance insights"""
        if not self.sdk_available:
            return {"success": False, "error": "Meta SDK not available"}
        
        try:
            FacebookAdsApi.init(self.app_id, self.app_secret, access_token)
            
            campaign = Campaign(campaign_id)
            insights = campaign.get_insights(
                fields=["spend", "impressions", "clicks", "cpc", "ctr", "reach"],
                params={"date_preset": date_preset}
            )
            
            if insights:
                return {
                    "success": True,
                    "insights": dict(insights[0])
                }
            return {"success": True, "insights": {}}
        except Exception as e:
            return {"success": False, "error": str(e)}


meta_ads_service = MetaAdsService()
