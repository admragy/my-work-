"""
Ultra Ad System - 8 Golden Strategies for 100x ROI
Hunter Pro v4.0
"""
from typing import Dict, List, Optional, Any
from datetime import datetime
from enum import Enum


class AdStrategy(Enum):
    """8 Golden Ad Strategies"""
    NANO_INFLUENCER = "nano_influencer"
    UGC_CONTENT = "ugc_content"
    VIRAL_HOOK = "viral_hook"
    PROBLEM_AMPLIFY = "problem_amplify"
    REAL_SCARCITY = "real_scarcity"
    SOCIAL_PROOF_STACK = "social_proof_stack"
    PIXEL_OPTIMIZATION = "pixel_optimization"
    RETARGET_LADDER = "retarget_ladder"


STRATEGY_CONFIGS = {
    AdStrategy.NANO_INFLUENCER: {
        "name": "Nano Influencer",
        "name_ar": "مؤثرين صغار",
        "cost_range": "10-50 جنيه",
        "expected_roi": "50-200x",
        "best_for": "منتجات B2C",
        "description": "استخدم مؤثرين صغار (1k-10k متابع) - أرخص وأكثر مصداقية"
    },
    AdStrategy.UGC_CONTENT: {
        "name": "UGC Content",
        "name_ar": "محتوى المستخدمين",
        "cost_range": "0-20 جنيه",
        "expected_roi": "100-500x",
        "best_for": "دائماً",
        "description": "محتوى من العملاء الحقيقيين - أعلى مصداقية وأقل تكلفة"
    },
    AdStrategy.VIRAL_HOOK: {
        "name": "Viral Hook",
        "name_ar": "هوك فيروسي",
        "cost_range": "5 جنيه",
        "expected_roi": "Organic مجاني",
        "best_for": "محتوى مثير",
        "description": "أول 3 ثواني = كل حاجة. اصنع hook يوقف السكرول"
    },
    AdStrategy.PROBLEM_AMPLIFY: {
        "name": "Problem Amplify",
        "name_ar": "تضخيم المشكلة",
        "cost_range": "عادي",
        "expected_roi": "10x+",
        "best_for": "خدمات حل مشاكل",
        "description": "ضخّم المشكلة أولاً، ثم قدم الحل كإنقاذ"
    },
    AdStrategy.REAL_SCARCITY: {
        "name": "Real Scarcity",
        "name_ar": "ندرة حقيقية",
        "cost_range": "عادي",
        "expected_roi": "5-20x",
        "best_for": "عروض محدودة",
        "description": "ندرة حقيقية (مش وهمية) - كمية محدودة أو وقت محدود"
    },
    AdStrategy.SOCIAL_PROOF_STACK: {
        "name": "Social Proof Stack",
        "name_ar": "تكديس الإثبات الاجتماعي",
        "cost_range": "0-20 جنيه",
        "expected_roi": "20-100x",
        "best_for": "دائماً",
        "description": "شهادات + أرقام + قصص نجاح مكدسة فوق بعض"
    },
    AdStrategy.PIXEL_OPTIMIZATION: {
        "name": "Pixel Optimization",
        "name_ar": "تحسين البيكسل",
        "cost_range": "مجاني",
        "expected_roi": "تحسين 50%+",
        "best_for": "مستمر",
        "description": "حسّن البيكسل باستمرار - البيانات = الذهب"
    },
    AdStrategy.RETARGET_LADDER: {
        "name": "Retarget Ladder",
        "name_ar": "سلم الريتارجتينج",
        "cost_range": "30% الميزانية",
        "expected_roi": "200-1000x",
        "best_for": "أهم واحدة!",
        "description": "70% من الميزانية للريتارجتينج - أعلى ROI"
    }
}


class UltraAdSystem:
    """Ultra Ad System - 100x ROI Strategies"""
    
    def __init__(self):
        self.strategies = STRATEGY_CONFIGS
        self.campaigns = {}
        self.ad_templates = self._load_ad_templates()
    
    def _load_ad_templates(self) -> Dict:
        """Load ad templates for different strategies"""
        return {
            "hook_templates": [
                "توقف! {problem} بيأثر على {target} كل يوم...",
                "لو عندك {problem}، الفيديو ده ليك",
                "99% من {target} بيعملوا الغلطة دي...",
                "السر اللي {competitor} مش عايزك تعرفه...",
                "في 30 يوم بس، {result}... والدليل؟"
            ],
            "body_templates": [
                "المشكلة: {problem}\nالحل: {solution}\nالنتيجة: {result}",
                "قبل: {before}\nبعد: {after}\nالفرق: {difference}",
                "3 أسباب ليه {product} هو الحل:\n1. {reason1}\n2. {reason2}\n3. {reason3}"
            ],
            "cta_templates": [
                "احجز الآن - {scarcity}",
                "جرب مجاناً لمدة {trial_period}",
                "العرض ينتهي {deadline}",
                "أول 50 فقط يحصلوا على {bonus}"
            ]
        }
    
    def get_strategy_info(self, strategy: AdStrategy) -> Dict:
        """Get strategy information"""
        return self.strategies.get(strategy, {})
    
    def get_all_strategies(self) -> List[Dict]:
        """Get all strategies with info"""
        result = []
        for strategy, config in self.strategies.items():
            result.append({
                "id": strategy.value,
                **config
            })
        return result
    
    def recommend_strategies(self, product_type: str, budget: float, goal: str) -> List[Dict]:
        """Recommend best strategies based on inputs"""
        recommendations = []
        
        recommendations.append({
            "strategy": AdStrategy.RETARGET_LADDER,
            "priority": 1,
            "reason": "أعلى ROI دائماً - 70% من الميزانية",
            "budget_allocation": budget * 0.7
        })
        
        if budget < 100:
            recommendations.append({
                "strategy": AdStrategy.UGC_CONTENT,
                "priority": 2,
                "reason": "تكلفة منخفضة جداً مع ROI عالي",
                "budget_allocation": budget * 0.15
            })
        else:
            recommendations.append({
                "strategy": AdStrategy.NANO_INFLUENCER,
                "priority": 2,
                "reason": "مؤثرين صغار بتكلفة معقولة",
                "budget_allocation": budget * 0.15
            })
        
        recommendations.append({
            "strategy": AdStrategy.SOCIAL_PROOF_STACK,
            "priority": 3,
            "reason": "يعزز كل الاستراتيجيات الأخرى",
            "budget_allocation": budget * 0.15
        })
        
        return recommendations
    
    def generate_ad_copy(self, product: str, target_audience: str, problem: str, solution: str) -> Dict:
        """Generate ad copy using templates"""
        import random
        
        hook = random.choice(self.ad_templates["hook_templates"]).format(
            problem=problem,
            target=target_audience,
            competitor="المنافسين",
            result=solution
        )
        
        body = self.ad_templates["body_templates"][0].format(
            problem=problem,
            solution=solution,
            result=f"نتيجة مضمونة مع {product}"
        )
        
        cta = random.choice(self.ad_templates["cta_templates"]).format(
            scarcity="الأماكن محدودة",
            trial_period="7 أيام",
            deadline="خلال 48 ساعة",
            bonus="خصم 20%"
        )
        
        return {
            "hook": hook,
            "body": body,
            "cta": cta,
            "full_copy": f"{hook}\n\n{body}\n\n{cta}",
            "variations": self._generate_variations(hook, body, cta)
        }
    
    def _generate_variations(self, hook: str, body: str, cta: str) -> List[Dict]:
        """Generate A/B test variations"""
        return [
            {"name": "Version A", "hook": hook, "body": body, "cta": cta},
            {"name": "Version B", "hook": hook.replace("توقف!", "انتبه!"), "body": body, "cta": cta},
            {"name": "Version C", "hook": hook, "body": body, "cta": cta.replace("احجز", "سجل")}
        ]
    
    def create_campaign_plan(self, budget: float, product: str, target: str, duration_days: int = 7) -> Dict:
        """Create complete campaign plan"""
        daily_budget = budget / duration_days
        num_ads = max(5, int(budget / 5))
        budget_per_ad = budget / num_ads
        
        strategies = self.recommend_strategies(product, budget, "sales")
        
        return {
            "campaign_name": f"حملة {product}",
            "total_budget": budget,
            "duration_days": duration_days,
            "daily_budget": daily_budget,
            "num_ad_variants": num_ads,
            "budget_per_ad": budget_per_ad,
            "strategies": strategies,
            "targeting": {
                "audience_size": "5k-20k (دقيق)",
                "lookalike": "1% من أفضل العملاء",
                "exclusions": ["من اشترى", "غير مهتم"]
            },
            "schedule": {
                "day_1_3": "اختبار - 5 جنيه لكل إعلان",
                "day_4": "تحليل وإيقاف الخاسر",
                "day_5_7": "تكبير الرابح تدريجياً"
            },
            "budget_distribution": {
                "cold_audience": f"{budget * 0.3:.0f} جنيه (30%)",
                "retargeting": f"{budget * 0.7:.0f} جنيه (70%)"
            },
            "expected_roi": "30-50x",
            "kpis": ["CTR > 3%", "CPC < 1 جنيه", "ROAS > 10x"]
        }
    
    def analyze_campaign(self, campaign_data: Dict) -> Dict:
        """Analyze campaign performance"""
        reach = campaign_data.get("reach", 0)
        clicks = campaign_data.get("clicks", 0)
        conversions = campaign_data.get("conversions", 0)
        spend = campaign_data.get("spend", 1)
        revenue = campaign_data.get("revenue", 0)
        
        ctr = (clicks / reach * 100) if reach > 0 else 0
        cpc = spend / clicks if clicks > 0 else 0
        cpa = spend / conversions if conversions > 0 else 0
        roas = revenue / spend if spend > 0 else 0
        
        return {
            "metrics": {
                "reach": reach,
                "clicks": clicks,
                "conversions": conversions,
                "ctr": f"{ctr:.2f}%",
                "cpc": f"{cpc:.2f} جنيه",
                "cpa": f"{cpa:.2f} جنيه",
                "roas": f"{roas:.1f}x"
            },
            "health": "good" if roas > 5 else "needs_improvement",
            "recommendations": self._get_recommendations(ctr, cpc, roas)
        }
    
    def _get_recommendations(self, ctr: float, cpc: float, roas: float) -> List[str]:
        """Get recommendations based on metrics"""
        recs = []
        
        if ctr < 1:
            recs.append("CTR منخفض - حسّن الـ Hook والصورة")
        if cpc > 2:
            recs.append("CPC عالي - ضيّق الاستهداف")
        if roas < 3:
            recs.append("ROAS ضعيف - راجع الـ Landing Page")
        if not recs:
            recs.append("الأداء ممتاز! كبّر الميزانية تدريجياً")
        
        return recs
    
    def get_retargeting_ladder(self, budget: float) -> List[Dict]:
        """Get retargeting ladder setup"""
        return [
            {
                "level": 1,
                "audience": "زار الموقع آخر 3 أيام",
                "budget": budget * 0.35,
                "message": "رسالة عاجلة - عرض ينتهي قريباً"
            },
            {
                "level": 2,
                "audience": "أضاف للسلة ولم يشتري",
                "budget": budget * 0.30,
                "message": "منتجك لسه في السلة + خصم إضافي"
            },
            {
                "level": 3,
                "audience": "زار صفحة المنتج",
                "budget": budget * 0.20,
                "message": "شهادات عملاء + دليل اجتماعي"
            },
            {
                "level": 4,
                "audience": "تفاعل مع المحتوى",
                "budget": budget * 0.15,
                "message": "محتوى تعليمي + عرض تجربة"
            }
        ]


ultra_ad_system = UltraAdSystem()
