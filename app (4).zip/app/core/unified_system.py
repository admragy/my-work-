"""
Unified System - Event-Driven Architecture Core
Hunter Pro v4.0
"""
from typing import Dict, List, Optional, Any, Callable
from enum import Enum
from datetime import datetime
import asyncio
import json


class SystemEvent(Enum):
    """System-wide events"""
    LEAD_ADDED = "lead_added"
    LEAD_UPDATED = "lead_updated"
    LEAD_DELETED = "lead_deleted"
    LEAD_STAGE_CHANGED = "lead_stage_changed"
    LEAD_DISTRIBUTED = "lead_distributed"
    
    CAMPAIGN_CREATED = "campaign_created"
    CAMPAIGN_STARTED = "campaign_started"
    CAMPAIGN_STOPPED = "campaign_stopped"
    CAMPAIGN_COMPLETED = "campaign_completed"
    
    MESSAGE_SENT = "message_sent"
    MESSAGE_RECEIVED = "message_received"
    
    CHAT_MESSAGE = "chat_message"
    CHAT_RESPONSE = "chat_response"
    
    PROMPT_CHANGE = "prompt_change"
    RULE_ADDED = "rule_added"
    RULE_DELETED = "rule_deleted"
    
    ADMIN_MODIFICATION = "admin_modification"
    ADMIN_COMMAND = "admin_command"
    ADMIN_TEACH = "admin_teach"
    
    AI_LEARNING = "ai_learning"
    AI_STYLE_CHANGE = "ai_style_change"
    CONVERSION_SUCCESS = "conversion_success"
    
    SYSTEM_ERROR = "system_error"
    SYSTEM_READY = "system_ready"


class UserType(Enum):
    """User types in the system"""
    ADMIN = "admin"
    USER = "user"
    CLIENT = "client"


class LeadStage(Enum):
    """Lead funnel stages"""
    NEW = "new"
    BAIT_SENT = "bait_sent"
    REPLIED = "replied"
    INTERESTED = "interested"
    NEGOTIATING = "negotiating"
    HOT = "hot"
    CLOSED = "closed"
    LOST = "lost"


class UnifiedSystem:
    """
    Central Hub - Event-Driven Architecture
    Everything connects through this system
    """
    
    _instance = None
    _listeners: Dict[SystemEvent, List[Callable]] = {}
    _state: Dict[str, Any] = {}
    _rules: List[Dict] = []
    _learned_patterns: List[Dict] = []
    _active_campaigns: Dict[str, Dict] = {}
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialize()
        return cls._instance
    
    def _initialize(self):
        """Initialize the unified system"""
        self._listeners = {event: [] for event in SystemEvent}
        self._state = {
            "initialized_at": datetime.now().isoformat(),
            "version": "4.0.0",
            "total_events": 0,
            "active_users": 0,
            "total_leads": 0,
            "conversion_rate": 0.0
        }
        self._rules = self._load_default_rules()
        self._learned_patterns = []
        self._active_campaigns = {}
    
    def _load_default_rules(self) -> List[Dict]:
        """Load default sales rules"""
        return [
            {
                "id": "price_objection",
                "stage": "negotiating",
                "condition": ["غالي", "سعر عالي", "مكلف"],
                "response": "عرض ROI للعميل وحساب التوفير",
                "action": "offer_value_calculation"
            },
            {
                "id": "thinking_objection",
                "stage": "interested",
                "condition": ["هفكر", "محتاج وقت", "هرجعلك"],
                "response": "خلق إلحاح ذكي مع احترام قراره",
                "action": "create_urgency"
            },
            {
                "id": "competitor_mention",
                "stage": "negotiating",
                "condition": ["فيه أرخص", "شركة تانية", "منافس"],
                "response": "إبراز المميزات الفريدة والقيمة المضافة",
                "action": "differentiate"
            },
            {
                "id": "ready_to_buy",
                "stage": "hot",
                "condition": ["موافق", "عايز اشتري", "تمام", "ابعتلي"],
                "response": "إتمام الصفقة فوراً مع تسهيل الإجراءات",
                "action": "close_deal"
            },
            {
                "id": "trust_issue",
                "stage": "interested",
                "condition": ["مش متأكد", "إزاي أثق", "فيه ضمان"],
                "response": "تقديم شهادات العملاء والضمانات",
                "action": "build_trust"
            }
        ]
    
    def on(self, event: SystemEvent, callback: Callable):
        """Register event listener"""
        if event not in self._listeners:
            self._listeners[event] = []
        self._listeners[event].append(callback)
    
    def off(self, event: SystemEvent, callback: Callable):
        """Remove event listener"""
        if event in self._listeners and callback in self._listeners[event]:
            self._listeners[event].remove(callback)
    
    async def emit(self, event: SystemEvent, data: Dict = None):
        """Emit event to all listeners"""
        self._state["total_events"] += 1
        
        event_data = {
            "event": event.value,
            "data": data or {},
            "timestamp": datetime.now().isoformat()
        }
        
        if event in self._listeners:
            for callback in self._listeners[event]:
                try:
                    if asyncio.iscoroutinefunction(callback):
                        await callback(event_data)
                    else:
                        callback(event_data)
                except Exception as e:
                    await self.emit(SystemEvent.SYSTEM_ERROR, {"error": str(e), "source": event.value})
    
    def get_state(self) -> Dict:
        """Get current system state"""
        return self._state.copy()
    
    def update_state(self, key: str, value: Any):
        """Update system state"""
        self._state[key] = value
    
    def add_rule(self, rule: Dict) -> bool:
        """Add new sales rule"""
        if "id" not in rule:
            rule["id"] = f"rule_{len(self._rules) + 1}"
        self._rules.append(rule)
        return True
    
    def delete_rule(self, rule_id: str) -> bool:
        """Delete a rule by ID"""
        for i, rule in enumerate(self._rules):
            if rule.get("id") == rule_id:
                self._rules.pop(i)
                return True
        return False
    
    def get_rules(self, stage: str = None) -> List[Dict]:
        """Get rules, optionally filtered by stage"""
        if stage:
            return [r for r in self._rules if r.get("stage") == stage]
        return self._rules.copy()
    
    def find_matching_rule(self, message: str, stage: str) -> Optional[Dict]:
        """Find rule matching message and stage"""
        message_lower = message.lower()
        for rule in self._rules:
            if rule.get("stage") == stage:
                conditions = rule.get("condition", [])
                for cond in conditions:
                    if cond in message_lower:
                        return rule
        return None
    
    def add_learned_pattern(self, pattern: Dict):
        """Add learned pattern from successful conversations"""
        pattern["learned_at"] = datetime.now().isoformat()
        pattern["usage_count"] = 0
        self._learned_patterns.append(pattern)
    
    def get_learned_patterns(self, situation: str = None) -> List[Dict]:
        """Get learned patterns"""
        if situation:
            return [p for p in self._learned_patterns if situation.lower() in p.get("situation", "").lower()]
        return self._learned_patterns.copy()
    
    def register_campaign(self, campaign_id: str, campaign_data: Dict):
        """Register active campaign"""
        campaign_data["registered_at"] = datetime.now().isoformat()
        self._active_campaigns[campaign_id] = campaign_data
    
    def update_campaign(self, campaign_id: str, updates: Dict):
        """Update campaign data"""
        if campaign_id in self._active_campaigns:
            self._active_campaigns[campaign_id].update(updates)
            return True
        return False
    
    def get_campaign(self, campaign_id: str) -> Optional[Dict]:
        """Get campaign by ID"""
        return self._active_campaigns.get(campaign_id)
    
    def get_active_campaigns(self) -> Dict[str, Dict]:
        """Get all active campaigns"""
        return self._active_campaigns.copy()
    
    def identify_user_type(self, user_id: str, is_admin: bool = False) -> UserType:
        """Identify user type"""
        if is_admin:
            return UserType.ADMIN
        return UserType.USER
    
    def get_stats(self) -> Dict:
        """Get system statistics"""
        return {
            "version": self._state.get("version", "4.0.0"),
            "total_events": self._state.get("total_events", 0),
            "total_rules": len(self._rules),
            "learned_patterns": len(self._learned_patterns),
            "active_campaigns": len(self._active_campaigns),
            "uptime": self._state.get("initialized_at")
        }


unified_system = UnifiedSystem()
