"""
Auto Follow-up Service - المتابعة التلقائية على الماسنجر
لو اليوزر مش رد، المستشار الذكي بيكمل المحادثة
"""

import os
import json
import asyncio
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from collections import defaultdict
import httpx

try:
    from openai import OpenAI
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False


class AutoFollowUpService:
    """خدمة المتابعة التلقائية على الماسنجر"""
    
    def __init__(self):
        self.pending_followups: Dict[str, List[Dict]] = defaultdict(list)
        self.followup_settings: Dict[str, Dict] = {}
        self.active_conversations: Dict[str, Dict] = {}
        self.is_running = False
        
        if HAS_OPENAI and os.environ.get("OPENAI_API_KEY"):
            self.openai_client = OpenAI()
        else:
            self.openai_client = None
        
        self.followup_templates = {
            "first": [
                "أهلاً! شفت رسالتك وحبيت أتأكد إنك شفت العرض 🔥",
                "مرحباً! لسه مستني ردك على العرض الحصري 💯",
                "هاي! العرض لسه متاح لو حابب تستفيد منه 🎁"
            ],
            "second": [
                "تاني متابعة معاك! العرض قرب يخلص ⏰",
                "حبيت أفكرك إن العرض الحصري هينتهي قريب 🚨",
                "آخر فرصة للعرض! تحب أحجزلك؟ 💪"
            ],
            "third": [
                "آخر رسالة مني 😊 لو مش مهتم مفيش مشكلة، بس لو عايز أي مساعدة أنا موجود",
                "مش هزعجك تاني، بس لو احتجت أي حاجة راسلني في أي وقت 🙏",
                "أتمنى ألقاك قريب! لو غيرت رأيك العرض لسه موجود 🌟"
            ]
        }
    
    def configure_user_settings(self, user_id: str, settings: Dict) -> Dict:
        """تكوين إعدادات المتابعة للمستخدم"""
        default_settings = {
            "enabled": True,
            "max_followups": 3,
            "first_delay_hours": 2,
            "second_delay_hours": 24,
            "third_delay_hours": 72,
            "use_ai_messages": True,
            "custom_messages": None,
            "stop_on_reply": True,
            "active_hours": {"start": 9, "end": 22}
        }
        
        self.followup_settings[user_id] = {**default_settings, **settings}
        return self.followup_settings[user_id]
    
    def get_user_settings(self, user_id: str) -> Dict:
        """الحصول على إعدادات المستخدم"""
        return self.followup_settings.get(user_id, {
            "enabled": True,
            "max_followups": 3,
            "first_delay_hours": 2,
            "second_delay_hours": 24,
            "third_delay_hours": 72
        })
    
    async def check_unanswered_conversations(self, user_id: str, access_token: str, page_id: str) -> List[Dict]:
        """فحص المحادثات غير المجاب عليها"""
        unanswered = []
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"https://graph.facebook.com/v18.0/{page_id}/conversations",
                    params={
                        "access_token": access_token,
                        "fields": "id,participants,messages.limit(5){message,from,created_time}",
                        "limit": 50
                    },
                    timeout=30
                )
                
                if response.status_code != 200:
                    return []
                
                data = response.json()
                conversations = data.get("data", [])
                
                for conv in conversations:
                    messages = conv.get("messages", {}).get("data", [])
                    if not messages:
                        continue
                    
                    last_message = messages[0]
                    last_from = last_message.get("from", {}).get("id", "")
                    last_time = last_message.get("created_time", "")
                    
                    if last_from != page_id:
                        try:
                            msg_time = datetime.fromisoformat(last_time.replace('Z', '+00:00'))
                            hours_ago = (datetime.now(msg_time.tzinfo) - msg_time).total_seconds() / 3600
                            
                            settings = self.get_user_settings(user_id)
                            if hours_ago >= settings.get("first_delay_hours", 2):
                                unanswered.append({
                                    "conversation_id": conv.get("id"),
                                    "customer_id": last_from,
                                    "last_message": last_message.get("message", ""),
                                    "hours_waiting": hours_ago,
                                    "messages_count": len(messages)
                                })
                        except Exception as e:
                            print(f"Error parsing time: {e}")
        
        except Exception as e:
            print(f"Error checking unanswered: {e}")
        
        return unanswered
    
    async def generate_followup_message(self, user_id: str, conversation: Dict, followup_number: int) -> str:
        """توليد رسالة متابعة"""
        settings = self.get_user_settings(user_id)
        
        if settings.get("custom_messages"):
            custom = settings["custom_messages"]
            if followup_number == 1 and custom.get("first"):
                return custom["first"]
            elif followup_number == 2 and custom.get("second"):
                return custom["second"]
            elif followup_number == 3 and custom.get("third"):
                return custom["third"]
        
        if settings.get("use_ai_messages") and self.openai_client:
            return await self._generate_ai_followup(conversation, followup_number)
        
        templates = self.followup_templates.get(
            "first" if followup_number == 1 else "second" if followup_number == 2 else "third",
            self.followup_templates["first"]
        )
        
        import random
        return random.choice(templates)
    
    async def _generate_ai_followup(self, conversation: Dict, followup_number: int) -> str:
        """توليد رسالة متابعة بالـ AI"""
        try:
            urgency = "خفيفة" if followup_number == 1 else "متوسطة" if followup_number == 2 else "أخيرة"
            
            response = self.openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {
                        "role": "system",
                        "content": f"""أنت مسوق محترف مصري. اكتب رسالة متابعة {urgency} للعميل.
القواعد:
- استخدم اللهجة المصرية
- كن ودود ومش ملحّ
- استخدم إيموجي واحد أو اتنين
- الرسالة قصيرة (سطر أو اتنين)
- {"ده أول تواصل" if followup_number == 1 else "ده تاني تواصل" if followup_number == 2 else "دي آخر رسالة"}

اكتب الرسالة فقط بدون أي شرح."""
                    },
                    {
                        "role": "user",
                        "content": f"آخر رسالة من العميل: {conversation.get('last_message', '')}"
                    }
                ],
                max_tokens=100
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            print(f"AI followup error: {e}")
            import random
            return random.choice(self.followup_templates["first"])
    
    async def send_followup(self, access_token: str, page_id: str, recipient_id: str, message: str) -> Dict:
        """إرسال رسالة متابعة"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"https://graph.facebook.com/v18.0/{page_id}/messages",
                    params={"access_token": access_token},
                    json={
                        "recipient": {"id": recipient_id},
                        "message": {"text": message},
                        "messaging_type": "RESPONSE"
                    },
                    timeout=30
                )
                
                if response.status_code == 200:
                    return {"success": True, "message_id": response.json().get("message_id")}
                else:
                    return {"success": False, "error": response.text}
                    
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def process_auto_followups(self, user_id: str, access_token: str, page_id: str) -> Dict:
        """معالجة المتابعات التلقائية"""
        settings = self.get_user_settings(user_id)
        
        if not settings.get("enabled", True):
            return {"success": False, "message": "المتابعة التلقائية معطلة"}
        
        current_hour = datetime.now().hour
        active_hours = settings.get("active_hours", {"start": 9, "end": 22})
        if not (active_hours["start"] <= current_hour < active_hours["end"]):
            return {"success": False, "message": "خارج ساعات العمل"}
        
        result = {
            "success": True,
            "checked": 0,
            "sent": 0,
            "skipped": 0,
            "details": []
        }
        
        try:
            unanswered = await self.check_unanswered_conversations(user_id, access_token, page_id)
            result["checked"] = len(unanswered)
            
            for conv in unanswered:
                conv_id = conv["conversation_id"]
                hours = conv["hours_waiting"]
                
                tracking = self.active_conversations.get(f"{user_id}_{conv_id}", {})
                followup_count = tracking.get("followup_count", 0)
                
                if followup_count >= settings.get("max_followups", 3):
                    result["skipped"] += 1
                    continue
                
                next_followup = followup_count + 1
                delay_key = f"{'first' if next_followup == 1 else 'second' if next_followup == 2 else 'third'}_delay_hours"
                required_hours = settings.get(delay_key, 2)
                
                if hours >= required_hours:
                    message = await self.generate_followup_message(user_id, conv, next_followup)
                    
                    send_result = await self.send_followup(
                        access_token, page_id, conv["customer_id"], message
                    )
                    
                    if send_result["success"]:
                        result["sent"] += 1
                        self.active_conversations[f"{user_id}_{conv_id}"] = {
                            "followup_count": next_followup,
                            "last_sent": datetime.now().isoformat(),
                            "last_message": message
                        }
                        result["details"].append({
                            "conversation_id": conv_id,
                            "followup_number": next_followup,
                            "message": message[:50] + "..."
                        })
                    else:
                        result["details"].append({
                            "conversation_id": conv_id,
                            "error": send_result["error"]
                        })
                else:
                    result["skipped"] += 1
            
            result["message"] = f"تم فحص {result['checked']} محادثة - إرسال {result['sent']} متابعة"
            
        except Exception as e:
            result["success"] = False
            result["error"] = str(e)
        
        return result
    
    def mark_conversation_replied(self, user_id: str, conversation_id: str):
        """تسجيل أن المحادثة تم الرد عليها (لإيقاف المتابعة)"""
        key = f"{user_id}_{conversation_id}"
        if key in self.active_conversations:
            del self.active_conversations[key]
    
    async def start_background_worker(self, get_all_users_func, get_user_meta_func):
        """تشغيل العامل في الخلفية"""
        self.is_running = True
        
        while self.is_running:
            try:
                users = get_all_users_func()
                
                for user in users:
                    user_id = user.get("user_id") or user.get("username")
                    meta = get_user_meta_func(user_id)
                    
                    if meta and meta.get("access_token") and meta.get("page_id"):
                        await self.process_auto_followups(
                            user_id,
                            meta["access_token"],
                            meta["page_id"]
                        )
                
                await asyncio.sleep(300)
                
            except Exception as e:
                print(f"Auto followup worker error: {e}")
                await asyncio.sleep(60)
    
    def stop_background_worker(self):
        """إيقاف العامل"""
        self.is_running = False


auto_followup_service = AutoFollowUpService()
